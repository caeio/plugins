!function($) {

	$('#vc_ui-panel-edit-element').on('change', '.maa_extra_check_block input[type="checkbox"]', function(e){
		var $input = $(this);
		var $value_hidden_input = $(this).closest('.maa_extra_check_block').find('input.wpb_vc_param_value');
		if ($input.is(':checked')) {
			$value_hidden_input.val('1').change();
		} else {
			$value_hidden_input.val('0').change();
		}
	});

}(window.jQuery);