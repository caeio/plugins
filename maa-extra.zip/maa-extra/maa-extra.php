<?php
/*
	Plugin Name: Maa Shortcodes and Widgets
	Plugin URI: https://www.caeio.com
	Description: Supercharge Maa theme with pack of shortcodes, custom VC settings types and sidebar widgets
	Version: 1.0.0
	Author: caeio,LLC
	Author URI: https://www.caeio.com

	Copyright 2020 caeio, LLC (email: support@caeio.com)

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

$maa_extra_get_theme = wp_get_theme();

if ( in_array( $maa_extra_get_theme->get( 'TextDomain' ), array( 'maa', 'maa-child' ) ) ) {

	define( 'NOREBRO_EXTRA_DIR_PATH', plugin_dir_path( __FILE__ ) );

	add_action( 'plugins_loaded', 'maa_extra_load_plugin_textdomain' );

	function maa_extra_load_plugin_textdomain() {
		load_plugin_textdomain( 'maa-extra', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}

	add_action( 'vc_before_init', 'maa_extra_vc_init_plugin' );

	if ( function_exists( 'vc_set_shortcodes_templates_dir' ) ) {
		$vc_template_dir = plugin_dir_path( __FILE__ ) . 'vc_templates';
		vc_set_shortcodes_templates_dir( $vc_template_dir );
	}


	// Maa social shortcodes
	function maa_share_woo_func( ) {
		global $post;

		$social_networks = MaaSettings::get( 'woocommerce_sharing_networks', 'global' );

		if ( !$social_networks ) {
			return false;
		}

		$facebook_link = 'https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( get_permalink() );
		$twitter_link = 'https://twitter.com/intent/tweet?text=' . urlencode( $post->post_title ) . ',+' . rawurlencode( get_permalink() );
		$linkedin_link = 'https://www.linkedin.com/shareArticle?mini=true&url=' . rawurlencode( get_permalink() ) . '&title=' . urlencode( $post->post_title ) . '&source=' . urlencode( get_bloginfo( 'name' ) );
		$pinterest_link = 'http://pinterest.com/pin/create/button/?url=' . rawurlencode( get_permalink() ) . '&description=' . urlencode( $post->post_title );
		$vk_link = 'http://vk.com/share.php?url=' . rawurlencode( get_permalink() );
		?>

		<div class="woocommerce-share">
			<div class="wrap">
				<?php _e( 'Share this product', 'maa' ); ?>:
				<div class="socialbar flat">
				<?php
					foreach ( $social_networks as $link ) {
						switch ( $link ) {
							case 'facebook':
								echo '<a href="' . $facebook_link . '"><i class="fab fa-facebook-f"></i></a>';
								break;
							case 'twitter':
								echo '<a href="' . $twitter_link . '"><i class="fab fa-twitter"></i></a>';
								break;
							case 'linkedin':
								echo '<a href="' . $linkedin_link . '"><i class="fab fa-linkedin"></i></a>';
								break;
							case 'pinterest':
								echo '<a href="' . $pinterest_link . '"><i class="fab fa-pinterest-p"></i></a>';
								break;
							case 'vk':
								echo '<a href="' . $vk_link . '"><i class="fab fa-vk"></i></a>';
								break;
						}
					}
				?>
				</div>
			</div>
		</div>
		<?php return "";
	}
	add_shortcode( 'maa_share_woo', 'maa_share_woo_func' );

	function maa_share_blog_func( ) {
		global $post;

		$social_networks = MaaSettings::get( 'post_sharing_networks', 'global' );

		if ( !$social_networks ) {
			return false;
		}

		$facebook_link = 'https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( get_permalink() );
		$twitter_link = 'https://twitter.com/intent/tweet?text=' . urlencode( $post->post_title ) . ',+' . rawurlencode( get_permalink() );
		$linkedin_link = 'https://www.linkedin.com/shareArticle?mini=true&url=' . rawurlencode( get_permalink() ) . '&title=' . urlencode( $post->post_title ) . '&source=' . urlencode( get_bloginfo( 'name' ) );
		$pinterest_link = 'http://pinterest.com/pin/create/button/?url=' . rawurlencode( get_permalink() ) . '&description=' . urlencode( $post->post_title );
		$vk_link = 'http://vk.com/share.php?url=' . rawurlencode( get_permalink() );
		?>

		<div class="share" data-blog-share="true">
			<div class="title"><?php echo esc_html__( 'Share story', 'maa' ); ?></div>
			<div class="socialbar small outline default">
			<?php
				foreach ( $social_networks as $link ) {
					switch ( $link ) {
						case 'facebook':
							echo '<a href="' . $facebook_link . '" class="facebook"><span class="fab fa-facebook"></span></a>';
							break;
						case 'twitter':
							echo '<a href="' . $twitter_link . '" class="twitter"><span class="fab fa-twitter"></span></a>';
							break;
						case 'linkedin':
							echo '<a href="' . $linkedin_link . '" class="linkedin"><span class="fab fa-linkedin"></span></a>';
							break;
						case 'pinterest':
							echo '<a href="' . $pinterest_link . '" class="pinterest"><span class="fab fa-pinterest-p"></span></a>';
							break;
						case 'vk':
							echo '<a href="' . $vk_link . '" class="vk"><span class="fab fa-vk"></span></a>';
							break;
					}
				}
			?>
			</div>
		</div>
		<?php return "";
	}
	add_shortcode( 'maa_share_blog', 'maa_share_blog_func' );



	function maa_extra_vc_init_plugin() {
        $shortcodes_path = plugin_dir_path( __FILE__ ) . 'shortcodes/';
        $helpers_path 	= plugin_dir_path( __FILE__ ) . 'helpers/';
        $types_path 	= plugin_dir_path( __FILE__ ) . 'types/';

        // Helpers
        require_once $helpers_path . 'parsing.php';
        require_once $helpers_path . 'filtering.php';
        require_once $helpers_path . 'google_fonts.php';
        require_once $helpers_path . 'adobe_fonts.php';

        // VC param types
        require_once $types_path . 'input.php'; // Fully HTML allowed input
        require_once $types_path . 'button.php'; // Button settings
        require_once $types_path . 'columns.php'; // Columns settings
        require_once $types_path . 'colorpicker.php'; // Color picker settings
        require_once $types_path . 'choose_box.php'; // Radio select with images
        require_once $types_path . 'check.php'; // Pretty checkboxes
        require_once $types_path . 'divider.php'; // Simple titled divider
        require_once $types_path . 'typography.php'; // Powerfull typography module
        //require_once $types_path . 'icon_selector.php'; // Old extended icon selector
        require_once $types_path . 'icon_picker.php'; // Extended icon picker
        require_once $types_path . 'datetime.php'; // JQuery datetime selector
        require_once $types_path . 'portfolio_types.php'; // Dropdown with portfolio categories
        require_once $types_path . 'post_types.php'; // Dropdown with post categories
        require_once $types_path . 'woo_cats_types.php'; // Dropdown with WooCommerce categories

        // VC shortcodes
        $dh = opendir( $shortcodes_path );
        while ( false !== ( $filename = readdir( $dh ) ) ) {
          if ( substr( $filename, 0, 1) != '_' && strrpos( $filename, '.' ) === false ) {
            include_once $shortcodes_path . $filename . '/' . $filename . '.php';
            include_once $shortcodes_path . $filename . '/' . $filename . '__params.php';
          }
        }

        add_action('vc_after_init', function() {
        		// Custom setting for default row
				$useLinesData = array(
					'type' => 'maa_check',
					'heading' => __( 'Use through lines under background?', 'maa-extra' ),
					'param_name' => 'use_through_lines',
					'description' => __( '...', 'maa-extra' ),
					'value' => array(
						__( 'Yes, use lines for this row', 'maa-extra' ) => '0'
					)
				);
				vc_update_shortcode_param( 'vc_row', $useLinesData );

				$linesStyleData = array(
					'type' => 'dropdown',
					'heading' => __( 'Through lines background style', 'maa-extra' ),
					'param_name' => 'through_lines_style',
					'description' => __( '...', 'maa-extra' ),
					'value' => array(
						__( 'Dark', 'maa-extra' ) => 'dark',
						__( 'Light', 'maa-extra' ) => 'light'
					),
					'dependency' => array(
						'element' => 'use_through_lines',
						'value' => array(
							'1'
						)
					)
				);
				vc_update_shortcode_param( 'vc_row', $linesStyleData );

				$sideTitleData = array(
					'type' => 'textfield',
					'group' => __( 'Side Background Title', 'maa-extra' ),
					'heading' => __( 'Background title text', 'maa-extra' ),
					'param_name' => 'side_background_title',
					'description' => __( 'Recommended to use short headers.', 'maa-extra' ),
				);
				vc_update_shortcode_param( 'vc_row', $sideTitleData );

				$sideTitleAlignmentData = array(
					'type' => 'dropdown',
					'group' => __( 'Side Background Title', 'maa-extra' ),
					'heading' => __( 'Background title alignment', 'maa-extra' ),
					'param_name' => 'side_background_title_alignment',
					'value' => array(
						__( 'Left', 'maa-extra' ) => 'left',
						__( 'Right', 'maa-extra' ) => 'right'
					)
				);
				vc_update_shortcode_param( 'vc_row', $sideTitleAlignmentData );

				$sideTitleColorData = array(
					'type' => 'maa_colorpicker',
					'group' => __( 'Side Background Title', 'maa-extra' ),
					'heading' => __( 'Background title color', 'maa-extra' ),
					'param_name' => 'side_background_title_color',
					'description' => __( 'Recommended to use transparent or non-contrast colors.', 'maa-extra' ),
				);
				vc_update_shortcode_param( 'vc_row', $sideTitleColorData );

				$sideTitleTypoData = array(
					'type' => 'maa_typography',
					'group' => __( 'Side Background Title', 'maa-extra' ),
					'heading' => __( 'Background title typography', 'maa-extra' ),
					'param_name' => 'side_background_title_typo'
				);
				vc_update_shortcode_param( 'vc_row', $sideTitleTypoData );
			});
	}


	add_action( 'widgets_init', 'maa_extra_widgets_init_plugin' );

	function maa_extra_widgets_init_plugin() {
		$widgets_path = plugin_dir_path( __FILE__ ) . 'widgets/';

		require_once $widgets_path . 'widget.php';

		require_once $widgets_path . 'widget-about-author.php'; // About author. Multicontext widget
		require_once $widgets_path . 'widget-contacts.php'; // Contacts block widget
		require_once $widgets_path . 'widget-login.php'; // Login into Wordpress
		require_once $widgets_path . 'widget-logo.php'; // Show logo in sidebar
		require_once $widgets_path . 'widget-menu.php'; // Navigation widget
		require_once $widgets_path . 'widget-recent.php'; // Recent posts widget
		require_once $widgets_path . 'widget-socialbar-subscribe.php'; // ?
		require_once $widgets_path . 'widget-socialbar.php'; // Social bar icons with
		require_once $widgets_path . 'widget-subscribe.php'; // Subscribe by Feedburner feed
	}

	// ACF Maa fields extention
	require plugin_dir_path( __FILE__ ) . 'acf_ext/acf-fields.php';

} else {
	add_action( 'admin_notices', 'maa_extra_admin_notice' );

	function maa_extra_admin_notice() {
?>
	<div class="notice notice-error">
		<p>
			<strong><?php esc_html_e( '"Maa Shortcodes and Widgets" plugin is not supported by this theme', 'maa-extra' ); ?></strong>
			<br>
			<?php esc_html_e( 'Please use this plugin with Maa theme, or deactivate it.', 'maa' ); ?>
		</p>
	</div>
<?php
	}
}