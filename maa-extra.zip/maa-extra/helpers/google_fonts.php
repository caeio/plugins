<?php

	class NorExtraGoogleFonts {
		static public function get_google_fonts_array() {
			include '../acf_ext/gf_list.php';

			return $maa_gf_object;
		}
	}
