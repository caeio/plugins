<?php

class NorExtraAdobeFonts {

    static public function get_abobe_fonts_array() {

        $adobefonts_fonts = MaaSettings::get('adobekit_fonts', 'global');
        $maa_gf_list = '[';
        if (!empty($adobefonts_fonts) && is_array($adobefonts_fonts)) { $i = 0;
            foreach ($adobefonts_fonts as $adobefonts_font) { $i++;
                $maa_gf_list .= '
            {
                "font_family": "'.$adobefonts_font['font_family'].'",
                "font_styles": "';
                if (!empty($adobefonts_font['font_styles']) && is_array($adobefonts_font['font_styles'])) {
                    $j = 0;
                    foreach ($adobefonts_font['font_styles'] as $font_style) { $j++;
                        $maa_gf_list .= $font_style;
                        if ($j != count($adobefonts_font['font_styles'])) {
                            $maa_gf_list .= ',';
                        }

                    }
                }
                $maa_gf_list .= ' "
            }';
                if ($i != count($adobefonts_fonts)) {
                    $maa_gf_list .= ',';
                }
            }
        }
        $maa_gf_list .= ']';


        return json_decode( $maa_gf_list );
    }
}