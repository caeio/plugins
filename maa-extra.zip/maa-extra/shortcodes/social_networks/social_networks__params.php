<?php

/**
* Visual Composer Maa Social Networks shortcode params
*/

vc_map( array(
	'name' => __( 'Social Networks', 'maa-extra' ),
	'description' => __( 'Social sharing buttons block', 'maa-extra' ),
	'base' => 'maa_social_networks',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Icons layout', 'maa-extra' ),
			'param_name' => 'icon_layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_052.svg',
					'key' => 'outline',
					'title' => __( 'Outline', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_053.svg',
					'key' => 'fill',
					'title' => __( 'Fill', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_054.svg',
					'key' => 'flat',
					'title' => __( 'Flat', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_055.svg',
					'key' => 'inline',
					'title' => __( 'Inline', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_056.svg',
					'key' => 'text',
					'title' => __( 'Text', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_057.svg',
					'key' => 'boxed',
					'title' => __( 'Boxed', 'maa-extra' ),
				),
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Alignment', 'maa-extra' ),
			'param_name' => 'alignment',
			'std' => 'center',
			'value' => array(
				__( 'Left', 'maa-extra' ) => 'left',
				__( 'Center', 'maa-extra' ) => 'center',
				__( 'Right', 'maa-extra' ) => 'right',
			),
			'dependency' => array(
				'element' => 'icon_layout',
				'value' => array(
					'outline',
					'fill',
					'flat',
					'inline',
					'text'
				),
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Use small shapes', 'maa-extra' ),
			'param_name' => 'small_shapes',
			'std' => '0',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'icon_layout',
				'value' => array(
					'outline',
					'fill',
					'flat',
					'inline',
					'text'
				),
			),
		),

		// Links
		array(
			'type' => 'dropdown',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => __( 'Type links', 'maa-extra' ),
			'param_name' => 'type_links',
			'value' => array(
				__( 'Share', 'maa-extra' ) => 'share',
				__( 'Custom', 'maa-extra' ) => 'custom',
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-facebook"></em>' . __( 'Facebook share', 'maa-extra' ),
			'param_name' => 'facebook',
			'value' => array(
				__( 'Add', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'share',
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-twitter"></em>' . __( 'Twitter share', 'maa-extra' ),
			'param_name' => 'twitter',
			'value' => array(
				__( 'Add', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'share',
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-googleplus-outline"></em>' . __( 'Google+ share', 'maa-extra' ),
			'param_name' => 'googleplus',
			'value' => array(
				__( 'Add', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'share',
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-linkedin-outline"></em>' . __( 'LinkedIn share', 'maa-extra' ),
			'param_name' => 'linkedin',
			'value' => array(
				__( 'Add', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'share',
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-pinterest-outline"></em>' . __( 'Pinterest share', 'maa-extra' ),
			'param_name' => 'pinterest',
			'value' => array(
				__( 'Add', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'share',
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-vk"></em>' . __( 'Vkontakte share', 'maa-extra' ),
			'param_name' => 'vk',
			'value' => array(
				__( 'Add', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'share',
			),
		),
		/* Custom */
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-facebook"></em>' . __( 'Facebook link', 'maa-extra' ),
			'param_name' => 'facebook_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-twitter"></em>' . __( 'Twitter link', 'maa-extra' ),
			'param_name' => 'twitter_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-googleplus-outline"></em>' . __( 'Google+ link', 'maa-extra' ),
			'param_name' => 'googleplus_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-instagram-outline"></em>' . __( 'Instagram link', 'maa-extra' ),
			'param_name' => 'instagram_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-dribbble"></em>' . __( 'Dribbble link', 'maa-extra' ),
			'param_name' => 'dribbble_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-linkedin-outline"></em>' . __( 'LinkedIn link', 'maa-extra' ),
			'param_name' => 'linkedin_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-pinterest-outline"></em>' . __( 'Pinterest link', 'maa-extra' ),
			'param_name' => 'pinterest_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is ion-social-github"></em>' . __( 'GitHub link', 'maa-extra' ),
			'param_name' => 'github_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-dropbox"></em>' . __( 'Dropbox link', 'maa-extra' ),
			'param_name' => 'dropbox_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-vk"></em>' . __( 'Vkontakte link', 'maa-extra' ),
			'param_name' => 'vk_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-youtube"></em>' . __( 'Youtube link', 'maa-extra' ),
			'param_name' => 'youtube_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-vimeo"></em>' . __( 'Vimeo link', 'maa-extra' ),
			'param_name' => 'vimeo_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-behance"></em>' . __( 'Behance link', 'maa-extra' ),
			'param_name' => 'behance_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-tumblr"></em>' . __( 'Tumblr link', 'maa-extra' ),
			'param_name' => 'tumblr_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-flickr"></em>' . __( 'flickr link', 'maa-extra' ),
			'param_name' => 'flickr_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-reddit-alien"></em>' . __( 'reddit link', 'maa-extra' ),
			'param_name' => 'reddit_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-snapchat-ghost"></em>' . __( 'Snapchat link', 'maa-extra' ),
			'param_name' => 'snapchat_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-whatsapp"></em>' . __( 'Whatsapp link', 'maa-extra' ),
			'param_name' => 'whatsapp_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-quora"></em>' . __( 'Quora link', 'maa-extra' ),
			'param_name' => 'quora_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-vine"></em>' . __( 'Vine link', 'maa-extra' ),
			'param_name' => 'vine_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-digg"></em>' . __( 'Digg link', 'maa-extra' ),
			'param_name' => 'digg_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-foursquare"></em>' . __( 'Foursquare link', 'maa-extra' ),
			'param_name' => 'foursquare_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Links', 'maa-extra' ),
			'heading' => '<em class="maa_is fa fa-tripadvisor"></em>' . __( 'TripAdvisor link', 'maa-extra' ),
			'param_name' => 'tripadvisor_link_custom',
			'dependency' => array(
				'element' => 'type_links',
				'value' => 'custom',
			),
		),
		
		// Style
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Squared shape', 'maa-extra' ),
			'param_name' => 'shape_squared',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
			'std' => '0',
			'dependency' => array(
				'element' => 'icon_layout',
				'value' => array(
					'fill',
					'outline',
					'flat'
				),
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Outline hover', 'maa-extra' ),
			'param_name' => 'outline_hover',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'icon_layout',
				'value' => 'flat',
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Default colors', 'maa-extra' ),
			'param_name' => 'default_colors',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Hover default colors', 'maa-extra' ),
			'param_name' => 'hover_default_colors',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'default_colors',
				'value' => '0',
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Shape color', 'maa-extra' ),
			'param_name' => 'color',
			'dependency' => array(
				'element' => 'default_colors',
				'value' => '0',
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Icon color', 'maa-extra' ),
			'param_name' => 'icon_color',
			'dependency' => array(
				'element' => 'default_colors',
				'value' => '0',
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Icon hover color', 'maa-extra' ),
			'param_name' => 'icon_hover_color',
			'dependency' => array(
				'element' => 'default_colors',
				'value' => '0',
			),
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );