<?php

/**
* Visual Composer Maa Button shortcode params
*/

vc_map( array(
	'name' => __( 'Button', 'maa-extra' ),
	'description' => __( 'Simple eye catching button', 'maa-extra' ),
	'base' => 'maa_button',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Button layout', 'maa-extra' ),
			'param_name' => 'layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_023.svg',
					'key' => 'fill',
					'title' => __( 'Fill', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_024.svg',
					'key' => 'outline',
					'title' => __( 'Outline', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_025.svg',
					'key' => 'flat',
					'title' => __( 'Flat', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_026.svg',
					'key' => 'link',
					'title' => __( 'Link', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'vc_link',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Link', 'maa-extra' ),
			'param_name' => 'link',
			'description' => __( 'Fill link text field to change the \'Get started\' label.', 'maa-extra' ),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Button size', 'maa-extra' ),
			'param_name' => 'shape_size',
			'std' => 'default',
			'value' => array(
				__( 'Small', 'maa-extra' ) => 'small',
				__( 'Default', 'maa-extra' ) => 'default',
				__( 'Large', 'maa-extra' ) => 'large',
				__( 'Huge', 'maa-extra' ) => 'huge',
			),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Button position', 'maa-extra' ),
			'param_name' => 'shape_position',
			'std' => 'center',
			'value' => array(
				__( 'Left', 'maa-extra' ) => 'left',
				__( 'Center', 'maa-extra' ) => 'center',
				__( 'Right', 'maa-extra' ) => 'right',
			),
			'description' => __( 'You can choose button alignment position.', 'maa-extra' ),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Full width', 'maa-extra' ),
			'param_name' => 'full_width',
			'value' => array(
				__( 'Yes, set 100% width', 'maa-extra' ) => '0'
			),
		),

		// Icon
		array(
			'type' => 'maa_check',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Add icon', 'maa-extra' ),
			'param_name' => 'icon_use',
			'value' => array(
				__( 'Yes, add icon', 'maa-extra' ) => '0'
			),
			'description' => __( 'You can add icon instead or with text.', 'maa-extra' )
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Swap icon to text on hover', 'maa-extra' ),
			'param_name' => 'text_on_hover',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'icon_use',
				'value' => '1'
			),
			'description' => __( 'This add "rolling" effect on hover.', 'maa-extra' ),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon position', 'maa-extra' ),
			'param_name' => 'icon_position',
			'std' => 'left',
			'value' => array(
				__( 'Left', 'maa-extra' ) => 'left',
				__( 'Right', 'maa-extra' ) => 'right',
			),
			'dependency' => array(
				'element' => 'icon_use',
				'value' => '1'
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon type', 'maa-extra' ),
			'param_name' => 'icon_type',
			'value' => array(
				__( 'Font icon', 'maa-extra' ) => 'font_icon',
				__( 'Custom image', 'maa-extra' ) => 'user_image'
			),
			'dependency' => array(
				'element' => 'icon_use',
				'value' => '1'
			),
			'description' => __( 'Choose icon from font icons packs or your custom image.', 'maa-extra' ),
		),
		array(
			'type' => 'maa_icon_picker',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon', 'maa-extra' ),
			'param_name' => 'icon_as_icon',
			'description' => __( 'Choose icon.', 'maa-extra' ),
			'settings' => array(),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'font_icon'
				)
			)
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon image', 'maa-extra' ),
			'param_name' => 'icon_as_image',
			'description' => __( 'Choose icon image.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'user_image'
				)
			)
		),

		// Typography
		array(
		'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_heading',
			'value' => __( 'Heading', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		
		// Style
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Squared shape', 'maa-extra' ),
			'param_name' => 'shape_squared',
			'value' => array(
				__( 'Yes, set squared shape', 'maa-extra' ) => '0'
			),
			'description' => __( 'By default, button have rounded corners shape.', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Button background', 'maa-extra' ),
			'param_name' => 'color',
			'description' => __( 'This color is also used for button border.', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Button background on hover', 'maa-extra' ),
			'param_name' => 'hover_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Text color', 'maa-extra' ),
			'param_name' => 'text_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Text color on hover', 'maa-extra' ),
			'param_name' => 'hover_text_color',
		),
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),


		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );