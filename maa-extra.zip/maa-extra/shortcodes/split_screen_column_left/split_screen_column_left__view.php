<?php

/**
* Visual Composer Maa Split Screen Left Column shortcode view
*/

?>
<div class="ms-left">

	<?php echo do_shortcode( $content ); ?>

</div>