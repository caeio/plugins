<?php 

/**
* Visual Composer Maa Split Screen Left Column shortcode
*/

add_shortcode( 'maa_split_screen_column_left', 'maa_split_screen_column_left_func' );

function maa_split_screen_column_left_func( $atts, $content = '' ) {
	// Assembling
	ob_start();
	include( plugin_dir_path( __FILE__ ) . 'split_screen_column_left__view.php' );
	return ob_get_clean();
}