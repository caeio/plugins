<?php

/**
* WPBakery Page Builder Stockie Instagram Feed shortcode params
*/

vc_map( array(
	'name' => __( 'Instagram Feed', 'maa-extra' ),
	'description' => __( 'Instagram feed module', 'maa-extra' ),
	'base' => 'maa_instagram_feed',
	'category' => __( 'Stockie', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'text',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Usage note:', 'maa-extra' ),
			'param_name' => 'photo_count',
			'description' => __( 'To use the shortcode please firstly install <a target="_blank" href="/wp-admin/plugins.php">Instagram Feed</a> from the recommended plugins. Then connect your Instagram account in the plugin\'s <a target="_blank" href="/wp-admin/admin.php?page=sb-instagram-feed">settings</a>.', 'maa-extra' ),
		),
        array(
            'type' => 'maa_check',
            'group' => __( 'General', 'maa-extra' ),
            'heading' => __( 'Show username?', 'maa-extra' ),
            'param_name' => 'header',
            'value' => array(
                'Yes' => true
            ),
            'default' => '0',
        ),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Number of photos', 'maa-extra' ),
			'param_name' => 'photo_count',
			'description' => __( 'Default 6. We recommend using a number that is suitable for the number of columns.', 'maa-extra' ),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Columns', 'maa-extra' ),
			'param_name' => 'columns',
			'value' => array(
				'1' => '1',
				'2' => '2',
				'3' => '3',
				'4' => '4',
				'6' => '6',
				'12' => '12',
			),
			'default' => '6',
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Remove columns gap?', 'maa-extra' ),
			'param_name' => 'columns_gap',
			'value' => array(
				'Yes' => '0'
			),
			'default' => '6',
		),

		// Custom CSS Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' )
		),
	)
) );