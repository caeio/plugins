<?php

/**
* Visual Composer Maa Subscribe shortcode params
*/

vc_map( array(
	'name' => __( 'Subscribe Module', 'maa-extra' ),
	'description' => __( 'Feed subscribe module', 'maa-extra' ),
	'base' => 'maa_subscribe',
	'category' => __( 'Maa', 'maa-extra' ),
	'js_view' => 'VcMaaSubscribeView',
	'custom_markup' => '{{title}}<div class="vc_maa_subscribe-container">
		<em>%%title%%</em>
	</div>',
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Form type', 'maa-extra' ),
			'param_name' => 'input_type',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/param_type_default.png',
					'key' => 'default',
					'title' => __( 'Default', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/param_type_outline.png',
					'key' => 'outline',
					'title' => __( 'Outline', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/param_type_flat.png',
					'key' => 'flat',
					'title' => __( 'Flat', 'maa-extra' ),
				),
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Alignment', 'maa-extra' ),
			'param_name' => 'alignment',
			'std' => 'center',
			'value' => array(
				__( 'Left', 'maa-extra' ) => 'left',
				__( 'Center', 'maa-extra' ) => 'center',
				__( 'Right', 'maa-extra' )   => 'right',
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Squared shapes', 'maa-extra' ),
			'param_name' => 'squared_shapes',
			'value' => array(
				'Yes' => '0'
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Input placeholder', 'maa-extra' ),
			'value' => __( 'Enter your email', 'maa-extra' ),
			'param_name' => 'input_placeholder',
			'description' => __( 'Don\'t leave empty', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Button text', 'maa-extra' ),
			'value' => __( 'Subscribe', 'maa-extra' ),
			'param_name' => 'button_text',
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Feedburner feed name', 'maa-extra' ),
			'param_name' => 'feedburner_name',
			'description' => __( 'See <a href="https://feedburner.google.com/" target="_blank">Feedburner.com</a> service', 'maa-extra' ),
		),
		 
		// Style
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Full width', 'maa-extra' ),
			'param_name' => 'fullwidth',
			'value' => array(
				__( 'Yes, sure', 'maa-extra' ) => '1'
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Input color', 'maa-extra' ),
			'param_name' => 'input_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Input background color', 'maa-extra' ),
			'param_name' => 'input_bg_color',
			'dependency' => array(
				'element' => 'input_type',
				'value' => array(
					'flat'
				)
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Input border color', 'maa-extra' ),
			'param_name' => 'input_border_color',
			'dependency' => array(
				'element' => 'input_type',
				'value' => array(
					'default',
					'outline'
				)
			)
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_button',
			'value' => __( 'Button', 'maa-extra' ),
		),
		array(
			'type' => 'maa_button',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'button',
			'color_brand' => true,
			'button_link_disabled' => '1',
			'button_size_disabled' => '1',
			'button_squared_disabled' => '1',
			'button_full_disabled' => '1',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Appearance effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Appearance effect duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000(ms), with step 50.', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),
	)
) );