<?php

/**
* Visual Composer Maa Time Line Group shortcode view
*/

?>
<div class="maa-timeline-sc timeline<?php echo $css_class; ?>">

	<?php echo do_shortcode( $content ); ?>

</div>