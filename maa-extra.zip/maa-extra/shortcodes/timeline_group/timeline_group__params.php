<?php


vc_map( array(
	'name' => __( 'Timeline', 'maa-extra' ), 
	'description' => __( 'Timeline group module', 'maa-extra' ), 
	'base' => 'maa_timeline_group',
	'category' => __( 'Maa', 'maa-extra' ), 
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'js_view' => 'VcMaaTimelineInnerView',
	'show_settings_on_create' => false,
	'as_parent' => array(
		'only' => 'maa_timeline_inner',
	),
	'default_content' => '[maa_timeline_inner][/maa_timeline_inner]',
	'params' => array(
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Alignment', 'maa-extra' ),
			'param_name' => 'alignment',
			'value' => array(
				__( 'Left', 'maa-extra' ) => 'left',
				__( 'Right', 'maa-extra' ) => 'right',
			),
		),
	
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),
	)
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Maa_Timeline_Group extends WPBakeryShortCodesContainer {	}
}