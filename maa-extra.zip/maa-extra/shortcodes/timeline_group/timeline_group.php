<?php 

/**
* Visual Composer Maa Time Line Group shortcode
*/

add_shortcode( 'maa_timeline_group', 'maa_timeline_group_func' );

function maa_timeline_group_func( $atts, $content = '' ) {
	if ( isset( $atts ) && is_array( $atts ) ) extract( $atts );

	// Default values, parsing and filtering
	$alignment = isset( $alignment ) ? NorExtraFilter::string( $alignment, 'string', 'left' ) : 'left';
	$css_class = isset( $css_class ) ? ' ' . NorExtraFilter::string( $css_class, 'attr', '' )  : '';

	if ( $alignment == 'right' ) {
		$css_class .= ' right';
	}

	// Assembling
	ob_start();
	include( plugin_dir_path( __FILE__ ) . 'timeline_group__view.php' );
	return ob_get_clean();
}