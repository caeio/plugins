<?php

/**
* Visual Composer Maa List Module shortcode params
*/

vc_map( array(
	'name' => __( 'List Module', 'maa-extra' ),
	'description' => __( 'Elements list block', 'maa-extra' ),
	'base' => 'maa_list_module',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'List layout', 'maa-extra' ),
			'param_name' => 'list_layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_040.svg',
					'key' => 'default',
					'title' => __( 'Default', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_041.svg',
					'key' => 'border_items',
					'title' => __( 'Border Items', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_042.svg',
					'key' => 'offset_border_items',
					'title' => __( 'Offset Border', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'List style', 'maa-extra' ),
			'param_name' => 'list_style',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_040.svg',
					'key' => 'default',
					'title' => __( 'Default', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_043.svg',
					'key' => 'line',
					'title' => __( 'Line', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_044.svg',
					'key' => 'icon',
					'title' => __( 'Icon', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_045.svg',
					'key' => 'shape_icon',
					'title' => __( 'Shape Icon', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'param_group',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'List items', 'maa-extra' ),
			'param_name' => 'list_value_type1',
			'value' => array(
				false
			),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => __( 'Title', 'maa-extra' ),
					'param_name' => 'list_title',
				),
			),
			'dependency' => array(
				'element' => 'list_style',
				'value' => array(
					'default',
					'line'
				)
			)
		),
		array(
			'type' => 'param_group',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'List items', 'maa-extra' ),
			'param_name' => 'list_value_type2',
			'value' => array(
				false
			),
			'params' => array(
				array(
					'type' => 'maa_icon_picker',
					'heading' => __( 'Icon', 'maa-extra' ),
					'param_name' => 'list_icon',
					'description' => __( 'Choose icon.', 'maa-extra' ),
					'settings' => array(),
				),
				array(
					'type' => 'attach_image',
					'heading' => __( 'or Icon image', 'maa-extra' ),
					'param_name' => 'list_image',
					'description' => __( 'If you select an image, then choosed an icon will be ignored.', 'maa-extra' ),
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Title', 'maa-extra' ),
					'param_name' => 'list_title',
				),
			),
			'dependency' => array(
				'element' => 'list_style',
				'value' => array(
					'icon',
					'shape_icon'
				)
			)						
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		
		// Style
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Border color', 'maa-extra' ),
			'param_name' => 'border_color',
			'dependency' => array(
				'element' => 'list_layout',
				'value' => array(
					'border_items',
					'offset_border_items'
				)
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Icon color', 'maa-extra' ),
			'param_name' => 'icon_color',
			'dependency' => array(
				'element' => 'list_style',
				'value' => array(
					'shape_icon',
					'icon'
				)
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Icon shape color', 'maa-extra' ),
			'param_name' => 'icon_shape_color',
			'dependency' => array(
				'element' => 'list_style',
				'value' => 'shape_icon'
			),
			'value' => 'brand'
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );