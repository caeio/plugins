<?php

/**
* Visual Composer Maa Pie Chart shortcode params
*/

vc_map( array(
	'name' => __( 'Pie Chart', 'maa-extra' ),
	'description' => __( 'Chart box module', 'maa-extra' ),
	'base' => 'maa_pie_chart',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Pie chart layout', 'maa-extra' ),
			'param_name' => 'layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_046.svg',
					'key' => 'percent',
					'title' => __( 'Percent', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_047.svg',
					'key' => 'icon',
					'title' => __( 'Icon', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Description position', 'maa-extra' ),
			'param_name' => 'description_position',
			'value' => array(
				__( 'Bottom', 'maa-extra' ) => 'bottom',
				__( 'Right', 'maa-extra' ) => 'right',
				__( 'Left', 'maa-extra' ) => 'left'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Percent', 'maa-extra' ),
			'param_name' => 'percent',
			'value' => '100',
			'description' => __( 'Percent of pie chart', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Title', 'maa-extra' ),
			'param_name' => 'title',
			'value' => '',
			'description' => ''
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle', 'maa-extra' ),
			'param_name' => 'subtitle',
			'value' => '',
			'description' => ''
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle position', 'maa-extra' ),
			'param_name' => 'subtitle_position',
			'value' => array(
				__( 'Bottom', 'maa-extra' ) => 'bottom',
				__( 'Top', 'maa-extra' ) => 'top'
			)
		),

		// Icon
		array(
			'type' => 'dropdown',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon type', 'maa-extra' ),
			'param_name' => 'icon_type',
			'value' => array(
				__( 'Font icon', 'maa-extra' ) => 'font_icon',
				__( 'Custom image', 'maa-extra' ) => 'user_image'
			),
			'dependency' => array(
				'element' => 'layout',
				'value' => array(
					'icon'
				)
			)
		),
		array(
			'type' => 'maa_icon_picker',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon', 'maa-extra' ),
			'param_name' => 'icon_as_icon',
			'description' => __( 'Choose icon.', 'maa-extra' ),
			'settings' => array(),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'font_icon'
				)
			)
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon image', 'maa-extra' ),
			'param_name' => 'icon_as_image',
			'description' => __( 'Choose icon image.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'user_image'
				)
			)
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_percent',
			'value' => __( 'Percent', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'percent_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_subtitle',
			'value' => __( 'Subtitle', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'subtitle_typo',
		),
		
		// Style
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Chart color', 'maa-extra' ),
			'param_name' => 'chart_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Subtitle color', 'maa-extra' ),
			'param_name' => 'subtitle_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Chart content color', 'maa-extra' ),
			'param_name' => 'chart_content_color',
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );