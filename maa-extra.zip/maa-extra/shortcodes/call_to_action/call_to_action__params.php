<?php

/**
* Visual Composer Maa Call To Action shortcode params
*/

vc_map( array(
	'name' => __( 'Call To Action', 'maa-extra' ),
	'description' => __( 'Call to action block', 'maa-extra' ),
	'base' => 'maa_call_to_action',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(
		// General
		array(
			'type' => 'textarea_raw_html',
			'holder' => 'div class="maa_heading_VC_gap"',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Title', 'maa-extra' ),
			'param_name' => 'title',
			'description' => __( 'HTML allowed.', 'maa-extra' ),
		),
		array(
			'type' => 'textarea_raw_html',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle', 'maa-extra' ),
			'param_name' => 'subtitle',
			'description' => __( 'HTML allowed.', 'maa-extra' ),
		),

		// Link
		array(
			'type' => 'vc_link',
			'group' => __( 'Link', 'maa-extra' ),
			'heading' => __( 'Link', 'maa-extra' ),
			'param_name' => 'link',
			'description' => __( 'Fill title field to change the \'Get started\' label.', 'maa-extra' ),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Link', 'maa-extra' ),
			'heading' => __( 'Add icon?', 'maa-extra' ),
			'param_name' => 'icon_use',
			'value' => array(
				__( 'Yes, sure', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Link', 'maa-extra' ),
			'heading' => __( 'Icon position', 'maa-extra' ),
			'param_name' => 'icon_position',
			'std' => 'left',
			'value' => array(
				__( 'Left', 'maa-extra' ) => 'left',
				__( 'Right', 'maa-extra' ) => 'right',
			),
			'dependency' => array(
				'element' => 'icon_use',
				'value' => '1'
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Link', 'maa-extra' ),
			'heading' => __( 'Icon type', 'maa-extra' ),
			'param_name' => 'icon_type',
			'value' => array(
				__( 'Font icon', 'maa-extra' ) => 'font_icon',
				__( 'Custom image', 'maa-extra' ) => 'user_image'
			),
			'dependency' => array(
				'element' => 'icon_use',
				'value' => '1'
			)
		),
		array(
			'type' => 'maa_icon_picker',
			'group' => __( 'Link', 'maa-extra' ),
			'heading' => __( 'Icon', 'maa-extra' ),
			'param_name' => 'icon_as_icon',
			'description' => __( 'Choose icon.', 'maa-extra' ),
			'settings' => array(),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'font_icon'
				)
			)
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'Link', 'maa-extra' ),
			'heading' => __( 'Icon image', 'maa-extra' ),
			'param_name' => 'icon_as_image',
			'description' => __( 'Choose icon image.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'user_image'
				)
			)
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_subtitle',
			'value' => __( 'Subtitle', 'maa-extra' )
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'subtitle_typo'
		),

		// Style
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Show without side paddings', 'maa-extra' ),
			'param_name' => 'without_side_paddings',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Background color', 'maa-extra' ),
			'param_name' => 'bg_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Subtitle color', 'maa-extra' ),
			'param_name' => 'subtitle_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_readmore',
			'value' => __( 'Readmore button', 'maa-extra' ),
		),
		array(
			'type' => 'maa_button',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'readmore_button',
			'button_full_disabled' => 'true'
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),


		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	),
));