<?php

/**
* Visual Composer Maa Split Screen Right Column shortcode view
*/

?>
<div class="ms-right">

	<?php echo do_shortcode( $content ); ?>

</div>