<?php 

/**
* Visual Composer Maa Split Screen Right Column shortcode
*/

add_shortcode( 'maa_split_screen_column_right', 'maa_split_screen_column_right_func' );

function maa_split_screen_column_right_func( $atts, $content = '' ) {
	// Assembling
	ob_start();
	include( plugin_dir_path( __FILE__ ) . 'split_screen_column_right__view.php' );
	return ob_get_clean();
}