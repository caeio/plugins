<?php

/**
* Visual Composer Maa Countdown shortcode params
*/

vc_map( array(
	'name' => __( 'Countdown', 'maa-extra' ),
	'description' => __( 'Time countdown module', 'maa-extra' ),
	'base' => 'maa_countdown',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Countdown layout', 'maa-extra' ),
			'param_name' => 'layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_031.svg',
					'key' => 'default',
					'title' => __( 'Default', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_032.svg',
					'key' => 'boxed',
					'title' => __( 'Boxed', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Use rounded shape', 'maa-extra' ),
			'param_name' => 'rounded_shape',
			'value' => array(
				'Yes' => '0'
			),
			'dependency' => array(
				'element' => 'layout',
				'value' => 'boxed'
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Use classic style', 'maa-extra' ),
			'param_name' => 'countdown_classic',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'layout',
				'value' => 'default'
			)
		),
		array(
			'type' => 'maa_datetime',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Expiration date', 'maa-extra' ),
			'param_name' => 'countdown_date'
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_numbers',
			'value' => __( 'Numbers', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'numbers_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_titles',
			'value' => __( 'Titles', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'titles_typo'
		),
		
		// Style
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Numbers color', 'maa-extra' ),
			'param_name' => 'numbers_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Titles color', 'maa-extra' ),
			'param_name' => 'titles_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Divider dots', 'maa-extra' ),
			'param_name' => 'divider_dots_color',
			'dependency' => array(
				'element' => 'countdown_classic',
				'value' => '1'
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Box color', 'maa-extra' ),
			'param_name' => 'box_color',
			'dependency' => array(
				'element' => 'layout',
				'value' => 'boxed'
			)
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),


		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );