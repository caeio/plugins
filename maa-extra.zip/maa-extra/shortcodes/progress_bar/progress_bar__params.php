<?php

/**
* Visual Composer Maa Progress Bar shortcode params
*/

vc_map( array(
	'name' => __( 'Progress Bar', 'maa-extra' ),
	'description' => __( 'Progress bar section', 'maa-extra' ),
	'base' => 'maa_progress_bar',
	'category' => __( 'Maa', 'maa-extra' ),
	'js_view' => 'VcMaaProgressBarView',
	'custom_markup' => '{{title}}<div class="vc_maa_progress_bar-container"><em>%%title%%</em></div>',
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Progress bar layout', 'maa-extra' ),
			'param_name' => 'layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_048.svg',
					'key' => 'default',
					'title' => __( 'Flat', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_049.svg',
					'key' => 'inner',
					'title' => __( 'Inner', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_050.svg',
					'key' => 'split',
					'title' => __( 'Split', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_051.svg',
					'key' => 'pattern',
					'title' => __( 'Pattern', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Percent in tooltip', 'maa-extra' ),
			'param_name' => 'percent_in_tooltip',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Label', 'maa-extra' ),
			'param_name' => 'name',
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Progress value', 'maa-extra' ),
			'param_name' => 'percent',
			'value' => '100',
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_name',
			'value' => __( 'Label', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'name_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_percent',
			'value' => __( 'Percent', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'percent_typo',
		),
		
		// Style
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Label color', 'maa-extra' ),
			'param_name' => 'label_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Percent color', 'maa-extra' ),
			'param_name' => 'percent_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Bar background color', 'maa-extra' ),
			'param_name' => 'bar_bg_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Bar line color', 'maa-extra' ),
			'param_name' => 'bar_line_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Tooltip color', 'maa-extra' ),
			'param_name' => 'tooltip_color',
			'dependency' => array(
				'element' => 'percent_in_tooltip',
				'value' => '1'
			),
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
)
);