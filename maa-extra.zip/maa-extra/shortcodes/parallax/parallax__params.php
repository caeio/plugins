<?php

/**
* Visual Composer Maa Parallax shortcode params
*/

vc_map( array(
	'name' => __( 'Parallax', 'maa-extra' ),
	'description' => __( 'Parallax block', 'maa-extra' ),
	'base' => 'maa_parallax',
	'category' => __( 'Maa', 'maa-extra' ),
	"content_element" => true,
	"is_container" => true,
	"js_view" => 'VcColumnView',
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'attach_image',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Image', 'maa-extra' ),
			'param_name' => 'image',
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Size', 'maa-extra' ),
			'param_name' => 'size',
			'value' => array(
				__( 'Auto', 'maa-extra' ) => '',
				__( 'Contain', 'maa-extra' ) => 'contain',
				__( 'Cover', 'maa-extra' )   => 'cover',
				__( 'auto 100%', 'maa-extra' )  => 'auto 100%',
				__( '100% auto', 'maa-extra' )  => '100% auto',
				__( '100% 100%', 'maa-extra' )  => '100% 100%',
			),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Parallax type', 'maa-extra' ),
			'param_name' => 'parallax',
			'value' => array(
				__( 'Vertical', 'maa-extra' ) => 'vertical',
				__( 'Horizontal', 'maa-extra' ) => 'horizontal'
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Parallax speed', 'maa-extra' ),
			'param_name' => 'parallax_speed',
			'description' => __( 'Parallax speed (default 1.0).', 'maa-extra' ),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Use overlay?', 'maa-extra' ),
			'param_name' => 'use_overlay',
			'value' => array(
				__( 'Yes, sure', 'maa-extra' ) => '0'
			)
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Overlay color', 'maa-extra' ),
			'param_name' => 'overlay_color',
			'dependency' => array(
				'element' => 'use_overlay',
				'value' => '1'
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' )
		),
	)
) );


if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Maa_Parallax extends WPBakeryShortCodesContainer {
		
	}
}