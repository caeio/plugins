<?php

/**
* Visual Composer Maa Vertical Fullscreen Slider shortcode view
*/

?>
<div class="maa-vertical-slider-sc maa-onepage disable-on-mobile <?php echo $css_class; ?>" 
	id="<?php echo esc_attr( $split_pages_uniqid ); ?>"
	data-options='<?php echo $onepage_json; ?>' 
	data-maa-onepage="true">

	<div class="onepage-stage">
		<?php echo do_shortcode( $content ); ?>
	</div>

</div>