<?php

/**
* Visual Composer Maa Vertical Fullscreen Slider shortcode params
*/

vc_map( array(
	'name' => __( 'Vertical Slider', 'maa-extra' ),
	'description' => __( 'Paged split view', 'maa-extra' ),
	'base' => 'maa_vertical_slider',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'holder' => '',
	'js_view' => 'VcMaaVerticalSliderView',
	'show_settings_on_create' => true,
	'content_element' => true,
	'is_container' => true,
	'as_parent' => array(
		'only' => 'maa_vertical_slider_inner'
	),
	'default_content' => '[maa_vertical_slider_inner][/maa_vertical_slider_inner]',
	'params' => array(
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Show navigation buttons?', 'maa-extra' ),
			'param_name' => 'navigation_show',
			'description' => __( 'Show navigation buttons on page' ),
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Show slides pagination?', 'maa-extra' ),
			'param_name' => 'pagination_show',
			'description' => __( 'Show pagination dots/numbers on page' ),
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Pagination color', 'maa-extra' ),
			'param_name' => 'elements_color'
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Pagination buttons type', 'maa-extra' ),
			'param_name' => 'pagination_type',
			'value' => array(
				__( 'Bullets', 'maa-extra' ) => 'bullets',
				__( 'Numbers', 'maa-extra' ) => 'numbers'
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Scroll animation duration', 'maa-extra' ),
			'param_name' => 'animation_duration',
			'value' => array(
				__( 'Default', 'maa-extra' ) => 'default',
				__( 'Fast', 'maa-extra' ) => 'fast',
				__( 'Slow', 'maa-extra' ) => 'slow'
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),
	)
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Maa_Vertical_Slider extends WPBakeryShortCodesContainer { }
}