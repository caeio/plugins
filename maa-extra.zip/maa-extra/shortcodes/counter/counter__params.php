<?php

/**
* Visual Composer Maa Counter shortcode params
*/

vc_map( array(
	'name' => __( 'Counter', 'maa-extra' ),
	'description' => __( 'Facts and numbers counter block', 'maa-extra' ),
	'base' => 'maa_counter',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(
		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Counter layout', 'maa-extra' ),
			'param_name' => 'layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_034.svg',
					'key' => 'number',
					'title' => __( 'Default', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_033.svg',
					'key' => 'number_with_icon',
					'title' => __( 'With icon', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle position', 'maa-extra' ),
			'param_name' => 'subtitle_position',
			'value' => array(
				__( 'Bottom', 'maa-extra' ) => 'bottom',
				__( 'Top', 'maa-extra' ) => 'top'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Number', 'maa-extra' ),
			'param_name' => 'count_number',
			'value' => '',
			'description' => __( 'The number of count', 'maa-extra' ),
		),
		array(
			'type' => 'textarea',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Title', 'maa-extra' ),
			'param_name' => 'title',
			'value' => '',
			'description' => __( 'Enter title text (HTML allowed).', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle', 'maa-extra' ),
			'param_name' => 'subtitle',
			'value' => '',
			'description' => __( 'Enter subtitle text.', 'maa-extra' ),
		),

		// Icon
		array(
			'type' => 'dropdown',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon position', 'maa-extra' ),
			'param_name' => 'icon_position',
			'value' => array(
				__( 'Left', 'maa-extra' ) => 'left',
				__( 'Right', 'maa-extra' ) => 'right',
				__( 'Top', 'maa-extra' ) => 'top'
			),
			'dependency' => array(
				'element' => 'layout',
				'value' => 'number_with_icon'
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon type', 'maa-extra' ),
			'param_name' => 'icon_type',
			'value' => array(
				__( 'Font icon', 'maa-extra' ) => 'font_icon',
				__( 'Custom image', 'maa-extra' ) => 'user_image'
			),
			'dependency' => array(
				'element' => 'layout',
				'value' => array(
					'number_with_icon',
					'icon'
				)
			)
		),
		array(
			'type' => 'maa_icon_picker',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon', 'maa-extra' ),
			'param_name' => 'icon_as_icon',
			'description' => __( 'Choose icon.', 'maa-extra' ),
			'settings' => array(),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'font_icon'
				)
			)
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon image', 'maa-extra' ),
			'param_name' => 'icon_as_image',
			'description' => __( 'Choose icon image.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'user_image'
				)
			)
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_count',
			'value' => __( 'Number of count', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'count_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_subtitle',
			'value' => __( 'Subtitle', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'subtitle_typo',
		),
		
		// Style
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Number color', 'maa-extra' ),
			'param_name' => 'count_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Icon color', 'maa-extra' ),
			'param_name' => 'icon_color',
			'dependency' => array(
				'element' => 'layout',
				'value' => 'number_with_icon'
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Subtitle color', 'maa-extra' ),
			'param_name' => 'subtitle_color'
		),

		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),


		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );