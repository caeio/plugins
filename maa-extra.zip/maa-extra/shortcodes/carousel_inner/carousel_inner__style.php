<?php

/**
* Visual Composer Maa Carousel Inner shortcode custom styles
*/
