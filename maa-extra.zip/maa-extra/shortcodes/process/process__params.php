<?php

/**
* Visual Composer Maa Process shortcode params
*/

vc_map( array(
	'name' => __( 'Process', 'maa-extra' ),
	'description' => '',
	'base' => 'maa_process',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(
		// General
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Number', 'maa-extra' ),
			'param_name' => 'number',
			'description' => __( 'Process number.', 'maa-extra' ),
			'value' => 'Fox example, "01."',
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Title', 'maa-extra' ),
			'param_name' => 'title',
			'description' => __( 'Main title for block.', 'maa-extra' ),
		),
		array(
			'type' => 'textarea',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Description', 'maa-extra' ),
			'param_name' => 'description',
			'description' => __( 'Description content.', 'maa-extra' ),
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_number',
			'value' => __( 'Number', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'number_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_description',
			'value' => __( 'Description', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'description_typo',
		),

		// Style
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Boxed', 'maa-extra' ),
			'param_name' => 'boxed',
			'value' => array(
				'Yes' => '0'
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Background color', 'maa-extra' ),
			'param_name' => 'bg_color',
			'dependency' => array(
				'element' => 'boxed',
				'value' => '1'
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Number color', 'maa-extra' ),
			'param_name' => 'number_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Description color', 'maa-extra' ),
			'param_name' => 'description_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );