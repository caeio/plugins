<?php

/**
* Visual Composer Maa Recent Posts shortcode params
*/

vc_map( array(
	'name' => __( 'Recent Posts', 'maa-extra' ),
	'description' => __( 'Block with recent posts', 'maa-extra' ),
	'base' => 'maa_recent_posts',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(
		// General
		array(
			'type' => 'maa_post_types',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Post categories', 'maa-extra' ),
			'param_name' => 'post_category',
			'value' => ''
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Blog layout', 'maa-extra' ),
			'param_name' => 'card_layout',
			'value' => array(
				__( 'Classic', 'maa-extra' ) => 'classic',
				__( 'Side image', 'maa-extra' ) => 'side_image',
				__( 'Overlay', 'maa-extra' ) => 'overlay',
				__( 'Simple', 'maa-extra' ) => 'simple',
				__( 'Striped', 'maa-extra' ) => 'striped'
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Use boxed style for items?', 'maa-extra' ),
			'param_name' => 'card_boxed',
			'description' => __( 'Append box wrapper for post cards', 'maa-extra' ),
			'value' => array(
				__( 'Wrap in box', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'classic',
					'side_image',
					'striped'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Show cards in striped view?', 'maa-extra' ),
			'param_name' => 'card_striped',
			'description' => __( '', 'maa-extra' ),
			'value' => array(
				__( 'Striped view', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'striped'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Add indented to cards view?', 'maa-extra' ),
			'param_name' => 'card_indented',
			'description' => __( '', 'maa-extra' ),
			'value' => array(
				__( 'Indented view', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'striped'
				)
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Grid animation', 'maa-extra' ),
			'param_name' => 'animation_type',
			'value' => array(
				__( 'Without animation', 'maa-extra' ) => 'default',
				__( 'Sync animation', 'maa-extra' ) => 'sync',
				__( 'Async animation', 'maa-extra' ) => 'async'
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Animation effect', 'maa-extra' ),
			'param_name' => 'animation_effect',
			'value' => array(
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'maa_columns',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Blog items per row', 'maa-extra' ),
			'param_name' => 'columns_in_row',
			'std' => '4-3-2-1'
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Blog items per page', 'maa-extra' ),
			'param_name' => 'posts_in_block',
			'description' => __( 'Chose number of last projects in the block.', 'maa-extra' ),
			'value' => 12
		),
		
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Items gap', 'maa-extra' ),
			'param_name' => 'card_gap',
			'description' => __( 'Use CSS value.', 'maa-extra' ),
			'value' => '30px'
		),

		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_card_content_typo',
			'value' => __( 'Card content', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'text_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_card_heading_typo',
			'value' => __( 'Card heading', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'heading_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_card_info_typo',
			'value' => __( 'Card info subtitles', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'subtitle_typo',
		),

		// Pagination
		array(
			'type' => 'maa_check',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Enable pagination', 'maa-extra' ),
			'param_name' => 'use_pagination',
			'description' => '',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Pagination type', 'maa-extra' ),
			'param_name' => 'pagination_type',
			'value' => array(
				__( 'Simple', 'maa-extra' ) => 'simple',
				__( 'Lazy load', 'maa-extra' ) => 'lazy_scroll',
				__( 'Load more button', 'maa-extra' ) => 'lazy_button',
			),
			'std' => 'simple',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => array(
					'1'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Blog items per page', 'maa-extra' ),
			'param_name' => 'pagination_items_per_page',
			'value' => '6',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => array(
					'1'
				)
			)
		),

		// Style
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_colors',
			'value' => __( 'Card colors', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Card background color', 'maa-extra' ),
			'param_name' => 'card_background_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Card text color', 'maa-extra' ),
			'param_name' => 'card_text_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Card heading color', 'maa-extra' ),
			'param_name' => 'card_heading_color',
			'description' => __( 'Color for post title link.', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Card info subtitle color', 'maa-extra' ),
			'param_name' => 'card_subtitle_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Pagination color', 'maa-extra' ),
			'param_name' => 'pagination_color',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Pagination hover and active color', 'maa-extra' ),
			'param_name' => 'pagination_active_color',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );