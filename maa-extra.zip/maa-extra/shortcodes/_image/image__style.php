<?php

/**
 * Visual Composer Maa Image shortcode custom style
 */

/*
$_style_block = '';

if ( $floating_css ) {
    $_style_block .= '#' . $image_uniqid . '{';
    $_style_block .= $floating_css;
    $_style_block .= '}';
}

MaaLayout::append_to_shortcodes_css_buffer( $_style_block );
*/