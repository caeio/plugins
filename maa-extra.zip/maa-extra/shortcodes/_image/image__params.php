<?php

/**
 * Visual Composer Maa Image shortcode params
 */

vc_map( array(
    'name' => __( 'Image', 'maa-extra' ),
    'description' => __( 'Simple block with image', 'maa-extra' ),
    'base' => 'maa_image',
    'category' => __( 'Maa', 'maa-extra' ),
    'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
    'params' => array(

        // General
        array(
            'type' => 'attach_image',
            'group' => __( 'General', 'maa-extra' ),
            'heading' => __( 'Image', 'maa-extra' ),
            'param_name' => 'image_url',
            'description' => __( 'Choose your image.', 'maa-extra' ),
        ),
        array(
            'type' => 'maa_choose_box',
            'group' => __( 'General', 'maa-extra' ),
            'heading' => __( 'Alignment', 'maa-extra' ),
            'param_name' => 'alignment',
            'value' => array(
                array(
                    'icon' => plugin_dir_url( __FILE__ ) . 'images/param_alignment_left.png',
                    'key' => 'left',
                    'title' => __( 'Left', 'maa-extra' ),
                ),
                array(
                    'icon' => plugin_dir_url( __FILE__ ) . 'images/param_alignment_center.png',
                    'key' => 'center',
                    'title' => __( 'Center', 'maa-extra' ),
                ),
                array(
                    'icon' => plugin_dir_url( __FILE__ ) . 'images/param_alignment_right.png',
                    'key' => 'right',
                    'title' => __( 'Right', 'maa-extra' ),
                )
            )
        ),
        /*array(
            'type' => 'maa_choose_box',
            'group' => __( 'General', 'maa-extra' ),
            'heading' => __( 'Floating', 'maa-extra' ),
            'param_name' => 'float',
            'value' => array(
                array(
                    'icon' => plugin_dir_url( __FILE__ ) . 'images/vs_settings_icon75.png',
                    'key' => 'left',
                    'title' => __( 'Left', 'maa-extra' ),
                ),
                array(
                    'icon' => plugin_dir_url( __FILE__ ) . 'images/vs_settings_icon73.png',
                    'key' => 'both',
                    'title' => __( 'Both', 'maa-extra' ),
                ),
                array(
                    'icon' => plugin_dir_url( __FILE__ ) . 'images/vs_settings_icon73.png',
                    'key' => 'right',
                    'title' => __( 'Right', 'maa-extra' ),
                )
            ),
        ),*/
        array(
            'type' => 'textfield',
            'group' => __( 'General', 'maa-extra' ),
            'heading' => __( 'Title', 'maa-extra' ),
            'param_name' => 'title',
            'description' => __( 'Used for <em>title</em> and <em>alt</em> attributs.', 'maa-extra' ),
        ),
        array(
            'type' => 'dropdown',
            'group' => __( 'Styles and Colors', 'maa-extra' ),
            'heading' => __( 'Appearance effect', 'maa-extra' ),
            'param_name' => 'appearance_effect',
            'value' => array(
                __( 'None', 'maa-extra' ) => 'none',
                __( 'Fade up', 'maa-extra' ) => 'fade-up',
                __( 'Fade down', 'maa-extra' ) => 'fade-down',
                __( 'Fade right', 'maa-extra' ) => 'fade-right',
                __( 'Fade left', 'maa-extra' ) => 'fade-left',
                __( 'Flip up', 'maa-extra' ) => 'flip-up',
                __( 'Flip down', 'maa-extra' ) => 'flip-down',
                __( 'Zoom in', 'maa-extra' ) => 'zoom-in',
                __( 'Zoom out', 'maa-extra' ) => 'zoom-out'
            )
        ),
        array(
            'type' => 'textfield',
            'group' => __( 'Styles and Colors', 'maa-extra' ),
            'heading' => __( 'Appearance effect duration', 'maa-extra' ),
            'param_name' => 'appearance_duration',
            'description' => __( 'Duration accept values from 50 to 3000(ms), with step 50.', 'maa-extra' ),
        ),
        array(
            'type' => 'textfield',
            'group' => __( 'Styles and Colors', 'maa-extra' ),
            'heading' => __( 'Custom CSS class', 'maa-extra' ),
            'param_name' => 'css_class',
            'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' )
        )
    )
) );