<?php

/**
* Visual Composer Maa Timeline Inner shortcode settings
*/

vc_map( array(
	'name' => __( 'Timeline', 'maa-extra' ),
	'description' => __( 'Timeline group module', 'maa-extra' ),
	'base' => 'maa_timeline_inner',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'content_element' => true,
	'as_child' => array(
		'only' => 'maa_timeline_group'
	),
	'params' => array(

		// General
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Boxed', 'maa-extra' ),
			'param_name' => 'boxed',
			'value' => array(
				'Yes' => '0'
			),
		),
		array(
			'type' => 'textfield',
			'holder' => 'em',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Title', 'maa-extra' ),
			'param_name' => 'title',
			'description' => __( 'Timeline title.', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle', 'maa-extra' ),
			'param_name' => 'subtitle',
			'description' => __( 'For example, <strong>2009 - 2012 Years</strong>.', 'maa-extra' ),
		),
		array(
			'type' => 'textarea',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Description', 'maa-extra' ),
			'param_name' => 'description',
		),

		/* Typography */
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_subtitle',
			'value' => __( 'Subtitle', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'subtitle_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_description',
			'value' => __( 'Description', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'desription_typo',
		),

		/* Styles */
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Background color', 'maa-extra' ),
			'param_name' => 'background_color',
			'value' => 'brand',
			'dependency' => array(
				'element' => 'boxed',
				'value' => array(
					'1'
				)
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Subtitle color', 'maa-extra' ),
			'param_name' => 'subtitle_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Description color', 'maa-extra' ),
			'param_name' => 'description_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Dot background color', 'maa-extra' ),
			'param_name' => 'dot_bg_color',
			'value' => ''
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Dot border color', 'maa-extra' ),
			'param_name' => 'dot_border_color',
			'value' => 'brand'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Line color', 'maa-extra' ),
			'param_name' => 'line_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' )
		),
	)
) );