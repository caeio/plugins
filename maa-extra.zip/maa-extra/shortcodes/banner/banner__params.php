<?php

/**
* Visual Composer Maa Banner shortcode params
*/

vc_map( array(
	'name' => __( 'Banner', 'maa-extra' ),
	'description' => __( 'Banner / Announcement box', 'maa-extra' ),
	'base' => 'maa_banner',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'js_view' => 'VcMaaBannerBoxView',
	'custom_markup' => '{{title}}<div class="vc_maa_banner_box-container">
			<div class="image" style="background-image: url(\'' . plugin_dir_url( __FILE__ ) . 'images/vc_gap_image.svg\');">
				<div class="title">%%title%%</div>
				<div class="lines">%%subtitle%%</div>
			</div>
		</div>',
	'params' => array(
		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Banner layout', 'maa-extra' ),
			'param_name' => 'block_type_layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_001.svg',
					'key' => 'full',
					'title' => __( 'Full content', 'maa-extra' )
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_004.svg',
					'key' => 'boxed',
					'title' => __( 'Boxed content', 'maa-extra' )
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_005.svg',
					'key' => 'inner',
					'title' => __( 'Inner content', 'maa-extra' )
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_006.svg',
					'key' => 'inner_hover',
					'title' => __( 'Hover content', 'maa-extra' )
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_007.svg',
					'key' => 'overlay_title',
					'title' => __( 'Overlay title', 'maa-extra' )
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_008.svg',
					'key' => 'hover_title',
					'title' => __( 'Hover title', 'maa-extra' )
				)
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Content alignment', 'maa-extra' ),
			'param_name' => 'block_type_full_align',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_001.svg',
					'key' => 'left',
					'title' => __( 'Left', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_002.svg',
					'key' => 'center',
					'title' => __( 'Center', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_003.svg',
					'key' => 'right',
					'title' => __( 'Right', 'maa-extra' ),
				)
			),
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle position', 'maa-extra' ),
			'param_name' => 'block_type_subtitle',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_009.svg',
					'key' => 'after',
					'title' => __( 'After title', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_010.svg',
					'key' => 'before',
					'title' => __( 'Before title', 'maa-extra' ),
				)
			),
		),
		array(
			'type' => 'textfield',
			'holder' => 'em',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Inner padding', 'maa-extra' ),
			'description' => __( 'Use CSS value.', 'maa-extra'),
			'param_name' => 'inner_padding',
			'std' => '30px'
		),

		array(
			'type' => 'textfield',
			'holder' => 'em',
			'group' => __( 'Content', 'maa-extra' ),
			'heading' => __( 'Title', 'maa-extra' ),
			'param_name' => 'title'
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Content', 'maa-extra' ),
			'heading' => __( 'Subtitle', 'maa-extra' ),
			'param_name' => 'subtitle',
		),
		array(
			'type' => 'textarea_raw_html',
			'group' => __( 'Content', 'maa-extra' ),
			'heading' => __( 'Description', 'maa-extra' ),
			'param_name' => 'description',
			'description' => __( 'Banner can be used as announcement block. Therefore, you can write text of the announcement for page / post / category / external link (HTML allowed).', 'maa-extra' )
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'Content', 'maa-extra' ),
			'heading' => __( 'Background image', 'maa-extra' ),
			'param_name' => 'background_image',
			'description' => __( 'Choose block background image.', 'maa-extra' ),
		),

		// Link
		array(
			'type' => 'maa_check',
			'group' => __( 'Link', 'maa-extra' ),
			'heading' => __( 'Use link?', 'maa-extra' ),
			'param_name' => 'use_link',
			'value' => array(
				__( 'Yes, sure', 'maa-extra' ) => '1'
			),
			'description' => __( 'You can use banner as link to another page.', 'maa-extra' ),
		),
		array(
			'type' => 'vc_link',
			'group' => __( 'Link', 'maa-extra' ),
			'heading' => __( 'Link URL', 'maa-extra' ),
			'param_name' => 'link_url',
			'dependency' => array(
				'element' => 'use_link',
				'value' => array(
					'1'
				)
			),
			'description' => __( 'Fill Link Text field to change the <strong>Read more</strong> label.', 'maa-extra' ),
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_subtitle',
			'value' => __( 'Subtitle', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'subtitle_typo'
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_description',
			'value' => __( 'Description', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'description_typo',
		),
		array(
			'type' => 'argenta_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_heading',
			'value' => __( 'Button text', 'maa-extra' ),
			'dependency' => array(
				'element' => 'use_link',
				'value' => array(
					'1'
				)
			),
		),
		array(
			'type' => 'argenta_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'button_typo',
			'dependency' => array(
				'element' => 'use_link',
				'value' => array(
					'1'
				)
			),
		),

		// Style
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_content',
			'value' => __( 'Content', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Subtitle color', 'maa-extra' ),
			'param_name' => 'subtitle_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Description color', 'maa-extra' ),
			'param_name' => 'description_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_readmore',
			'value' => __( 'Read more button', 'maa-extra' ),
			'dependency' => array(
				'element' => 'use_link',
				'value' => array(
					'1'
				)
			),
		),
		array(
			'type' => 'maa_button',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'readmore_button',
			'value' => 'type=outline&size=small',
			'dependency' => array(
				'element' => 'use_link',
				'value' => array(
					'1'
				)
			),
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Background overlay color', 'maa-extra' ),
			'param_name' => 'overlay_color',
			'value' => 'rgba(52, 52, 54, 0.9)',
			'dependency' => array(
				'element' => 'block_type_layout',
				'value' => array(
					'inner'
				)
			),
		),

		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );