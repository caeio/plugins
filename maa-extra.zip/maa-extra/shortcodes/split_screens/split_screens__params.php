<?php

/**
* Visual Composer Maa Split Screens shortcode params
*/

vc_map( array(
	'name' => __( 'Split Slider', 'maa-extra' ),
	'description' => __( 'Split view in slides', 'maa-extra' ),
	'base' => 'maa_split_screens',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'holder' => '',
	'js_view' => 'VcMaaSplitScreensView',
	'show_settings_on_create' => false,
	'content_element' => true,
	'is_container' => true,
	'as_parent' => array(
		'only' => 'maa_split_screen'
	),
	'default_content' => '[maa_split_screen][/maa_split_screen]',
	'params' => array(
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Scroll animation duration', 'maa-extra' ),
			'param_name' => 'animation_duration',
			'value' => array(
				__( 'Default', 'maa-extra' ) => 'default',
				__( 'Fast', 'maa-extra' ) => 'fast',
				__( 'Slow', 'maa-extra' ) => 'slow'
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Show navigation buttons?', 'maa-extra' ),
			'param_name' => 'navigation_buttons',
			'description' => __( 'Show navigation dots on page' ),
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Mousewheel scroll', 'maa-extra' ),
			'param_name' => 'mousewheel',
			'description' => __( 'Enable mouse scroll' ),
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Navigation buttons type', 'maa-extra' ),
			'param_name' => 'navigation_type',
			'value' => array(
				__( 'Bullets', 'maa-extra' ) => 'bullets',
				__( 'Numbers', 'maa-extra' ) => 'numbers'
			),
			'dependency' => array(
				'element' => 'navigation_buttons',
				'value' => array(
					'1',
					true
				)
			)
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Navigation buttons color', 'maa-extra' ),
			'param_name' => 'navigation_color',
			'dependency' => array(
				'element' => 'navigation_buttons',
				'value' => array(
					'1',
					true
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),
	)
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Maa_Split_Screens extends WPBakeryShortCodesContainer { }
}