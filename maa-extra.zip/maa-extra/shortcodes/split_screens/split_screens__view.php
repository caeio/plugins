<?php

/**
* Visual Composer Maa Split Screens shortcode view
*/

?>
<div class="maa-split-screen-sc maa-splitscreen<?php echo $css_class; ?>"
	id="<?php echo $split_screens_uniqid; ?>" 
	data-maa-splitscreen="true" 
	data-options='<?php echo $multiscroll_json; ?>' 
	<?php if ( $navigation_buttons ) { echo ' data-arg-splitscreen-nav="true"'; } ?>>

	<?php echo do_shortcode( $content ); ?>

</div>