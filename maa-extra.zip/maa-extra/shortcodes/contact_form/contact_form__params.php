<?php

/**
* Visual Composer Maa Contact Form shortcode params
*/

$maa_extra_cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

$maa_extra_contact_forms = array();
if ( $maa_extra_cf7 ) {
	foreach ( $maa_extra_cf7 as $cform ) {
		$maa_extra_contact_forms[ $cform->post_title ] = $cform->ID;
	}
} else {
	$maa_extra_contact_forms[ __( 'No contact forms found', 'maa-extra' ) ] = 0;
}

vc_map( array(
	'name' => __( 'Contact Form', 'maa-extra' ),
	'description' => __( 'Maa Contact 7 form module', 'maa-extra' ),
	'base' => 'maa_contact_form',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Form', 'maa-extra' ),
			'param_name' => 'form_id',
			'value' => $maa_extra_contact_forms,
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Form style', 'maa-extra' ),
			'param_name' => 'form_style',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_029.svg',
					'key' => 'classic',
					'title' => __( 'Default', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_030.svg',
					'key' => 'border',
					'title' => __( 'Outline', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_031.svg',
					'key' => 'flat',
					'title' => __( 'Flat', 'maa-extra' ),
				),
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Fields offset', 'maa-extra' ),
			'param_name' => 'fields_offset',
			'description' => __( 'CSS value.', 'maa-extra' ),
			'value' => '10px'
		),

		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_fields',
			'value' => __( 'Fields', 'maa-extra' ),
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Fields background color', 'maa-extra' ),
			'param_name' => 'fields_color',
			'dependency' => array(
				'element' => 'form_style',
				'value' => array(
					'flat',
				)
			)
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Fields border color', 'maa-extra' ),
			'param_name' => 'fields_border_color',
			'dependency' => array(
				'element' => 'form_style',
				'value' => array(
					'border',
					'classic'
				)
			)
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Fields text color', 'maa-extra' ),
			'param_name' => 'fields_text_color',
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Fields focus border color', 'maa-extra' ),
			'param_name' => 'fields_focus_border_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_button',
			'value' => __( 'Button', 'maa-extra' ),
		),
		array(
			'type' => 'maa_button',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'button',
			'value' => 'color=brand',
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Button position', 'maa-extra' ),
			'param_name' => 'button_position',
			'value' => array(
				__( 'Left', 'maa-extra' ) => 'left',
				__( 'Center', 'maa-extra' ) => 'center',
				__( 'Right', 'maa-extra' ) => 'right'
			),
		),

		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),

		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),


		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );