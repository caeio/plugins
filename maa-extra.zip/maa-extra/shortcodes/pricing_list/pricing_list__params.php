<?php

/**
* Visual Composer Maa Pricing List shortcode params
*/

vc_map( array(
	'name' => __( 'Pricing List', 'maa-extra' ),
	'description' => __( 'Pricing list module', 'maa-extra' ),
	'base' => 'maa_pricing_list',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Name', 'maa-extra' ),
			'param_name' => 'name'
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Details', 'maa-extra' ),
			'param_name' => 'indigriends'
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Sale price', 'maa-extra' ),
			'param_name' => 'sale_price'
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Regular price', 'maa-extra' ),
			'param_name' => 'regular_price'
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'New', 'maa-extra' ),
			'param_name' => 'new',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			)
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_name',
			'value' => __( 'Name', 'maa-extra' )
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'name_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_indigriends',
			'value' => __( 'Indigriends', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'indigriends_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_sale_price',
			'value' => __( 'Sale price', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'sale_price_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_regular_price',
			'value' => __( 'Regular price', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'regular_price_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_mark',
			'value' => __( 'Mark', 'maa-extra' ),
			'dependency' => array(
				'element' => 'new',
				'value' => '1'
			)
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'mark_typo',
			'dependency' => array(
				'element' => 'new',
				'value' => '1'
			)
		),

		// Style
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Name color', 'maa-extra' ),
			'param_name' => 'name_color',
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Indigriends color', 'maa-extra' ),
			'param_name' => 'indigriends_color',
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Sale price color', 'maa-extra' ),
			'param_name' => 'sale_price_color',
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Regular price color', 'maa-extra' ),
			'param_name' => 'regular_price_color',
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Border color', 'maa-extra' ),
			'param_name' => 'border_color',
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Mark color', 'maa-extra' ),
			'param_name' => 'mark_color',
			'dependency' => array(
				'element' => 'new',
				'value' => '1'
			)
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Mark background color', 'maa-extra' ),
			'param_name' => 'mark_background_color',
			'dependency' => array(
				'element' => 'new',
				'value' => '1'
			)
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );