<?php

/**
* Visual Composer Maa Google Maps shortcode params
*/

vc_map( array(
	'name' => __( 'Google Maps', 'maa-extra' ),
	'description' => __( 'Google Maps block', 'maa-extra' ),
	'base' => 'maa_google_maps',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'textarea',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Map marker locations', 'maa-extra' ),
			'param_name' => 'marker_locations',
			'description' => __( 'Use several locations by placing coordinates in separate rows. (e.g. 55.6925218, 12.5199567).', 'maa-extra' ),	
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Map height', 'maa-extra' ),
			'param_name' => 'map_height',
			'description' => __( 'Enter map height (in pixels or leave empty for responsive map).', 'maa-extra' ),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Enable map zoom buttons', 'maa-extra' ),
			'param_name' => 'map_zoom_enable',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Enable fullsreen button', 'maa-extra' ),
			'param_name' => 'map_fullscreen_enable',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Enable map type buttons', 'maa-extra' ),
			'param_name' => 'map_type_enable',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Enable map street view button', 'maa-extra' ),
			'param_name' => 'map_street_view_enable',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Map zoom', 'maa-extra' ),
			'param_name' => 'map_zoom',
			'description' => __( 'Map zoom level (min - 1, max - 20, default - 14)', 'maa-extra' ),
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Map marker image', 'maa-extra' ),
			'param_name' => 'map_marker',
			'description' => __( 'Choose marker image.', 'maa-extra' ),
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Map style', 'maa-extra' ),
			'param_name' => 'map_style',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/maps/default.png',
					'key' => 'default',
					'title' => __( 'Default', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/maps/light_dream.png',
					'key' => 'light_dream',
					'title' => __( 'Light Dream', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/maps/shades_of_grey.png',
					'key' => 'shades_of_grey',
					'title' => __( 'Shades of Grey', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/maps/paper.png',
					'key' => 'paper',
					'title' => __( 'Paper', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/maps/light_monochrome.png',
					'key' => 'light_monochrome',
					'title' => __( 'Monochrome', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/maps/lunar_landscape.png',
					'key' => 'lunar_landscape',
					'title' => __( 'Lunar', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/maps/routexl.png',
					'key' => 'routexl',
					'title' => __( 'Routexl', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/maps/flat_pale.png',
					'key' => 'flat_pale',
					'title' => __( 'Flat Pale', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/maps/flat_design.png',
					'key' => 'flat_design',
					'title' => __( 'Flat Design', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/maps/',
					'key' => 'custom',
					'title' => __( 'Custom', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'textarea_raw_html',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Custom map style', 'maa-extra' ),
			'description' => __( 'Paste JSON code. Customize style on <a target="_blank" href="https://mapstyle.withgoogle.com/">Styling Wizard</a>', 'maa-extra' ),
			'param_name' => 'custom_map_style',
			'dependency' => array(
				'element' => 'map_style',
				'value' => array(
					'custom'
				)
			)
		)
	)
) );