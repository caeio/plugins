<?php

/**
* Visual Composer Maa Pricing Table shortcode params
*/

vc_map( array(
	'name' => __( 'Pricing Table', 'maa-extra' ),
	'description' => __( 'Simple pricing table block', 'maa-extra' ),
	'base' => 'maa_pricing_table',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'js_view' => 'VcMaaPricingTableView',
	'custom_markup' => '{{title}}<div class="vc_maa_pricing_table-container">
			<div class="title">%%title%%</div>
			<div class="subtitle"></div>
			<div class="divider"></div>
			<div class="price"><span></span>%%price%%</div>
			<div class="divider"></div>
			<div class="item"></div>
			<div class="divider"></div>
			<div class="item"></div>
			<div class="divider"></div>
			<div class="item"></div>
			<div class="divider"></div>
			<div class="item"></div>
			<div class="divider"></div>
			<div class="read_more"></div>
		</div>',
	'params' => array(
		// General
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Title', 'maa-extra' ),
			'param_name' => 'title',
			'value' => '',
			'description' => __( 'You can specify the name of the tariff plan like <b>Basic</b> and <b>Business</b> or your product name.', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle', 'maa-extra' ),
			'param_name' => 'subtitle',
			'value' => '',
			'description' => ''
		),
		array(
			'type' => 'textarea',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Description', 'maa-extra' ),
			'param_name' => 'description',
			'value' => '',
			'description' => __( 'Short description.', 'maa-extra' ),
		),

		// Price
		array(
			'type' => 'textfield',
			'group' => __( 'Price', 'maa-extra' ),
			'heading' => __( 'Price', 'maa-extra' ),
			'param_name' => 'price',
			'value' => '',
			'description' => __( 'Number or specific phrases like <b>Free</b>, <b>Personal price</b> and <b>Beta testers only</b>.', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Price', 'maa-extra' ),
			'heading' => __( 'Currency', 'maa-extra' ),
			'param_name' => 'price_currency',
			'value' => '',
			'description' => __( '<b>&#36;</b>, <b>&euro;</b>, <b>&pound;</b>, <b>&yen;</b>, USD, EUR, anything.', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Price', 'maa-extra' ),
			'heading' => __( 'Caption', 'maa-extra' ),
			'param_name' => 'price_caption',
			'value' => '',
			'description' => __( 'You can write that this amount per year or month. For ex. <b>per month</b> or <b>per year</b>', 'maa-extra' ),
		),

		// Features
		array(
			'type' => 'param_group',
			'group' => __( 'Features', 'maa-extra' ),
			'heading' => __( 'Features', 'maa-extra' ),
			'param_name' => 'features_value',
			'value' => array(
				false
			),
			'params' => array(
				array(
					'type' => 'dropdown',
					'group' => __( 'Icon', 'maa-extra' ),
					'heading' => __( 'Icon', 'maa-extra' ),
					'param_name' => 'feature_icon',
					'value' => array(
						__( 'Without icon', 'maa-extra' ) => 'without_icon',
						__( 'Enable icon', 'maa-extra' ) => 'icon_plus',
						__( 'Disable icon', 'maa-extra' ) => 'icon_minus'
					),
				),
				array(
					'type' => 'textfield',
					'heading' => __( 'Title', 'maa-extra' ),
					'param_name' => 'feature_title',
				),
			),					
		),
		
		// Button
		array(
			'type' => 'maa_check',
			'group' => __( 'Button', 'maa-extra' ),
			'heading' => __( 'Add button', 'maa-extra' ),
			'param_name' => 'add_button',
			'value' => array(
				__( 'Yes, please', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'vc_link',
			'group' => __( 'Button', 'maa-extra' ),
			'heading' => __( 'Button link', 'maa-extra' ),
			'param_name' => 'button_link',
			'dependency' => array(
				'element' => 'add_button',
				'value' => array(
					'1'
				)
			),
			'description' => __( 'Fill title field to change the <strong>Get started</strong> inscription.', 'maa-extra' ),
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_subtitle',
			'value' => __( 'Subtitle', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'subtitle_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_description',
			'value' => __( 'Description', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'description_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_price',
			'value' => __( 'Price', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'price_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_features_title',
			'value' => __( 'Features title', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'features_title_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_features_subtitle',
			'value' => __( 'Features subtitle', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'features_subtitle_typo',
		),

		// Style
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_content',
			'value' => __( 'Content', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Background color', 'maa-extra' ),
			'param_name' => 'bg_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Borders color', 'maa-extra' ),
			'param_name' => 'borders_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Subtitle color', 'maa-extra' ),
			'param_name' => 'subtitle_color',
			'value' => 'brand'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Description color', 'maa-extra' ),
			'param_name' => 'description_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_price',
			'value' => __( 'Price', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Price color', 'maa-extra' ),
			'param_name' => 'price_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Price caption color', 'maa-extra' ),
			'param_name' => 'price_caption_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Price caption background color', 'maa-extra' ),
			'param_name' => 'price_caption_bg_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_features',
			'value' => __( 'Features', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Titles color', 'maa-extra' ),
			'param_name' => 'features_titles_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Icons color', 'maa-extra' ),
			'param_name' => 'features_icons_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Disabled titles color', 'maa-extra' ),
			'param_name' => 'features_disabled_titles_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Disabled icons color', 'maa-extra' ),
			'param_name' => 'features_disabled_icons_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_button',
			'value' => __( 'Button', 'maa-extra' ),
			'dependency' => array(
				'element' => 'add_button',
				'value' => array(
					'1'
				)
			),
		),
		array(
			'type' => 'maa_button',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'readmore_button',
			'value' => 'type=outline',
			'dependency' => array(
				'element' => 'add_button',
				'value' => array(
					'1'
				)
			),
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );