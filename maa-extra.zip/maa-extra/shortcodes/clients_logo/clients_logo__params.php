<?php

/**
* Visual Composer Maa Clients logo shortcode params
*/

vc_map( array(
	'name' => __( 'Clients Logo', 'maa-extra' ),
	'description' => __( 'Clients logo box', 'maa-extra' ),
	'base' => 'maa_clients_logo',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'js_view' => 'VcMaaClientsLogoView',
	'params' => array(
		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Clients logo layout', 'maa-extra' ),
			'param_name' => 'layout_type',
			'std' => 'default',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_027.svg',
					'key' => 'default',
					'title' => __( 'Default', 'maa-extra' )
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_028.svg',
					'key' => 'overlay',
					'title' => __( 'Info overlay', 'maa-extra' )
				),
			)
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Clients logo', 'maa-extra' ),
			'param_name' => 'image_logo',
		),
		array(
			'type' => 'textfield',
			'holder' => 'em',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Link', 'maa-extra' ),
			'param_name' => 'link',
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Open in new window?', 'maa-extra' ),
			'description' => __( '', 'maa-extra' ),
			'param_name' => 'in_new_tab',
			'value' => array(
				'Yes' => '0'
			),
		),
		array(
			'type' => 'textfield',
			'holder' => 'em',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Title', 'maa-extra' ),
			'param_name' => 'title',
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),
		array(
			'type' => 'textarea_raw_html',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Description', 'maa-extra' ),
			'param_name' => 'description',
			'description' => __( 'Enter description text (HTML allowed).', 'maa-extra' ),
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_description',
			'value' => __( 'Description', 'maa-extra' ),
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'description_typo',
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),


		// Style
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_content',
			'value' => __( 'Content', 'maa-extra' ),
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Overlay shadow', 'maa-extra' ),
			'param_name' => 'overlay_shadow',
			'value' => array(
				__( 'Yes, sure', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Overlay color', 'maa-extra' ),
			'param_name' => 'overlay_color',
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Description color', 'maa-extra' ),
			'param_name' => 'description_color',
			'dependency' => array(
				'element' => 'layout_type',
				'value' => array(
					'overlay'
				)
			),
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),


		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );
