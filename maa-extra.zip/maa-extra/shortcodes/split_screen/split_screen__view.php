<?php

/**
* Visual Composer Maa Split Screen shortcode view
*/

?>
<div class="ms-section<?php echo $css_class?>" id="<?php echo $split_screen_uniqid; ?>">

	<?php echo do_shortcode( $content ); ?>

</div>
