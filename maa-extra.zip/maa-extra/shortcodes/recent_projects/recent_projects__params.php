<?php

/**
* Visual Composer Maa Recent Projects shortcode params
*/

vc_map( array(
	'name' => __( 'Recent Projects', 'maa-extra' ),
	'description' => __( 'Recent Maa portfolio projects', 'maa-extra' ),
	'base' => 'maa_recent_projects',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(


		// General
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Portfolio layout', 'maa-extra' ),
			'param_name' => 'card_layout',
			'value' => array(
				__( 'Image Grid. Hover: centered details', 'maa-extra' ) => 'grid_1_hover_1',
				__( 'Image Grid. Hover: side details', 'maa-extra' ) => 'grid_1_hover_2',
				__( 'Image Grid. Hover: bottom details', 'maa-extra' ) => 'grid_1_hover_3',
				__( 'Classic Grid. Hover: simple opacity', 'maa-extra' ) => 'grid_2_hover_1',
				__( 'Classic Grid. Hover: overlay button', 'maa-extra' ) => 'grid_2_hover_2',
				__( 'Classic Grid. Hover: overlay link', 'maa-extra' ) => 'grid_2_hover_3',
				__( 'Fullscreen Carousel', 'maa-extra' ) => 'grid_4',
				__( 'Split Screen', 'maa-extra' ) => 'grid_5',
				__( 'Classic Carousel', 'maa-extra' ) => 'grid_6',
				__( 'Slider with Vertical Scroll', 'maa-extra' ) => 'grid_7',
				__( 'Slider with Horizontal Scroll', 'maa-extra' ) => 'grid_8',
			),
		),
        array(
            'type' => 'dropdown',
            'group' => __( 'General', 'maa-extra' ),
            'heading' => __( 'Portfolio item image size', 'maa-extra' ),
            'param_name' => 'portfolio_images_size',
            'value' => array(
                __( 'Theme settings inherited', 'maa-extra' ) => 'inherit',
                __( 'Thumbnail', 'maa-extra' ) => 'thumbnail',
                __( 'Small', 'maa-extra' ) => 'medium',
                __( 'Medium', 'maa-extra' ) => 'medium_large',
                __( 'Large', 'maa-extra' ) => 'large',
                __( 'Original', 'maa-extra' ) => 'full',
            ),
        ),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Metro style', 'maa-extra' ),
			'param_name' => 'metro_style',
			'description' => '',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_1_hover_1',
					'grid_1_hover_2',
					'grid_1_hover_3'
				)
			)
		),
		array(
			'type' => 'maa_portfolio_types',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Project categories', 'maa-extra' ),
			'param_name' => 'projects_category',
			'value' => ''
		),

		// Lightbox
		array(
			'type' => 'maa_check',
			'group' => __( 'Lightbox', 'maa-extra' ),
			'heading' => __( 'Enable lightbox preview for portfolio project', 'maa-extra' ),
			'param_name' => 'open_in_popup',
			'description' => '',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Lightbox', 'maa-extra' ),
			'heading' => __( 'Hide "View project" link from lightbox?', 'maa-extra' ),
			'param_name' => 'hide_view_link_in_popup',
			'description' => '',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'open_in_popup',
				'value' => array(
					'1'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Lightbox', 'maa-extra' ),
			'heading' => __( 'Show navigation buttons', 'maa-extra' ),
			'param_name' => 'popup_show_nav_buttons',
			'description' => '',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'open_in_popup',
				'value' => array(
					'1'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Lightbox', 'maa-extra' ),
			'heading' => __( 'Enable mouse wheel scrolling', 'maa-extra' ),
			'param_name' => 'popup_mouse_scrolling',
			'description' => '',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'open_in_popup',
				'value' => array(
					'1'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Lightbox', 'maa-extra' ),
			'heading' => __( 'Enable auto scrolling', 'maa-extra' ),
			'param_name' => 'popup_autoplay',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'open_in_popup',
				'value' => array(
					'1'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Lightbox', 'maa-extra' ),
			'heading' => __( 'Gallery autoplay time', 'maa-extra' ),
			'param_name' => 'popup_autoplay_time',
			'description' => __( 'Autoplay interval timeout in seconds. Default 5 second.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'popup_autoplay',
				'value' => '1',
			),
			'std' => '5'
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Grid animation', 'maa-extra' ),
			'param_name' => 'animation_type',
			'value' => array(
				__( 'Without animation', 'maa-extra' ) => 'default',
				__( 'Sync animation', 'maa-extra' ) => 'sync',
				__( 'Async animation', 'maa-extra' ) => 'async'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_1_hover_1',
					'grid_1_hover_2',
					'grid_1_hover_3',
					'grid_2_hover_1',
					'grid_2_hover_2',
					'grid_2_hover_3',
					'grid_3',
				)
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Grid animation effect', 'maa-extra' ),
			'param_name' => 'animation_effect',
			'value' => array(
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_1_hover_1',
					'grid_1_hover_2',
					'grid_1_hover_3',
					'grid_2_hover_1',
					'grid_2_hover_2',
					'grid_2_hover_3',
					'grid_3',
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Grid height', 'maa-extra' ),
			'param_name' => 'grid_height',
			'description' => __( 'CSS value. `100vh` for full viewport height', 'maa-extra' ),
			'value' => '500px',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_5',
					'grid_7',
					'grid_8'
				)
			)
		),
		array(
			'type' => 'maa_columns',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Portfolio items per row', 'maa-extra' ),
			'param_name' => 'columns_in_row',
			'std' => '4-3-2-1',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_1_hover_1',
					'grid_1_hover_2',
					'grid_1_hover_3',
					'grid_2_hover_1',
					'grid_2_hover_2',
					'grid_2_hover_3',
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Items gap', 'maa-extra' ),
			'param_name' => 'grid_items_gap',
			'description' => __( 'CSS value.', 'maa-extra' ),
			'value' => '15px',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_1_hover_1',
					'grid_1_hover_2',
					'grid_1_hover_3',
					'grid_2_hover_1',
					'grid_2_hover_2',
					'grid_2_hover_3',
					'grid_3',
					'grid_4',
					'grid_6'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Show category filter', 'maa-extra' ),
			'param_name' => 'show_projects_filter',
			'description' => '',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_1_hover_1',
					'grid_1_hover_2',
					'grid_1_hover_3',
					'grid_2_hover_1',
					'grid_2_hover_2',
					'grid_2_hover_3',
				)
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Category filter position', 'maa-extra' ),
			'param_name' => 'filter_align',
			'value' => array(
				__( 'Left', 'maa-extra' ) => 'left',
				__( 'Center', 'maa-extra' ) => 'center',
				__( 'Right', 'maa-extra' ) => 'right',
			),
			'std' => 'center',
			'dependency' => array(
				'element' => 'show_projects_filter',
				'value' => array(
					'1'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Enable pagination', 'maa-extra' ),
			'param_name' => 'use_pagination',
			'description' => '',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_1_hover_1',
					'grid_1_hover_2',
					'grid_1_hover_3',
					'grid_2_hover_1',
					'grid_2_hover_2',
					'grid_2_hover_3',
				)
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Pagination type', 'maa-extra' ),
			'param_name' => 'pagination_type',
			'value' => array(
				__( 'Simple', 'maa-extra' ) => 'simple',
				__( 'Lazy load', 'maa-extra' ) => 'lazy_scroll',
				__( 'Load more button', 'maa-extra' ) => 'lazy_button',
			),
			'std' => 'simple',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => array(
					'1'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Project items per page', 'maa-extra' ),
			'param_name' => 'projects_in_block',
			'description' => __( 'Choose a number of projects to be displayed', 'maa-extra' ),
			'value' => '4',
		),


		// Items
		array(
			'type' => 'maa_check',
			'group' => __( 'Items', 'maa-extra' ),
			'heading' => __( 'Offset slider items', 'maa-extra' ),
			'param_name' => 'offset_items',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_6'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Items', 'maa-extra' ),
			'heading' => __( 'How many items to display on desktop', 'maa-extra' ),
			'param_name' => 'item_desktop',
			'description' => __( 'Default value &mdash; 5 items.', 'maa-extra' ),
			'value' => '5',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_6'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Items', 'maa-extra' ),
			'heading' => __( 'How many items to display on tablet', 'maa-extra' ),
			'param_name' => 'item_tablet',
			'value' => '3',
			'description' => __( 'Default value &mdash; 3 items.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_6'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Items', 'maa-extra' ),
			'heading' => __( 'How many items to display on mobile', 'maa-extra' ),
			'param_name' => 'item_mobile',
			'value' => '1',
			'description' => __( 'Default value &mdash; 1 items.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_6'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Items', 'maa-extra' ),
			'heading' => __( 'Loop slider', 'maa-extra' ),
			'param_name' => 'loop',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_6'
				)
			)
		),

		// Pagination
		array(
			'type' => 'maa_check',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Enable mouse wheel srolling', 'maa-extra' ),
			'param_name' => 'mouse_wheel_srolling',
			'value' => array(
				__( 'Enable', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_5',
					'grid_6',
					'grid_7',
                    'grid_8'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Navigation dots', 'maa-extra' ),
			'param_name' => 'pagination_show',
			'value' => array(
				__( 'Show', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_5',
					'grid_6',
					'grid_7',
					'grid_8'
				)
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Dots type', 'maa-extra' ),
			'param_name' => 'pagination_slider_type',
			'value' => array(
				__( 'Numbers', 'maa-extra' ) => 'numbers',
				__( 'Dots', 'maa-extra' ) => 'dots'
			),
			'std' => 'numbers',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_5',
					'grid_7',
					'grid_8'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Navigation buttons', 'maa-extra' ),
			'param_name' => 'navigation_buttons',
			'value' => array(
				__( 'Show', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_5',
					'grid_6',
					'grid_7',
					'grid_8'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Dots each', 'maa-extra' ),
			'param_name' => 'dots_each',
			'description' => __( 'Show dots each x item.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_6'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Hide scroll label?', 'maa-extra' ),
			'param_name' => 'hide_slider_scroll_label',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_7',
					'grid_8'
				)
			)
		),

		// Slide
		array(
			'type' => 'textfield',
			'group' => __( 'Slide', 'maa-extra' ),
			'heading' => __( 'Slide by', 'maa-extra' ),
			'param_name' => 'slide_by',
			'description' => __( 'Navigation slide by x. `page` string can be set to slide by page.', 'maa-extra' ),
			'value' => '1',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_6'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Slide', 'maa-extra' ),
			'heading' => __( 'Slide speed', 'maa-extra' ),
			'param_name' => 'slide_speed',
			'description' => __( 'In milliseconds.', 'maa-extra' ),
			'value' => '500',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_6'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Slide', 'maa-extra' ),
			'heading' => __( 'Autoplay', 'maa-extra' ),
			'param_name' => 'autoplay',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_6'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Slide', 'maa-extra' ),
			'heading' => __( 'Autoplay time', 'maa-extra' ),
			'param_name' => 'autoplay_time',
			'description' => __( 'Autoplay interval timeout in seconds. Default 5 second.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'autoplay',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Slide', 'maa-extra' ),
			'heading' => __( 'Stop on hover', 'maa-extra' ),
			'param_name' => 'stop_on_hover',
			'description' => __( 'Stop autoplay on mouse hover.', 'maa-extra' ),
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '1'
			),
			'dependency' => array(
				'element' => 'autoplay',
				'value' => '1',
			)
		),

		// Style
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_card_title',
			'value' => __( 'Card content', 'maa-extra' ),
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Overlay color', 'maa-extra' ),
			'param_name' => 'overlay_color',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_1_hover_1',
					'grid_1_hover_2',
					'grid_1_hover_3',
					'grid_2_hover_2',
					'grid_4',
					'grid_7',
					'grid_8'
				)
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Background color', 'maa-extra' ),
			'param_name' => 'bg_color',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_5'
				)
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Category outline', 'maa-extra' ),
			'param_name' => 'category_outline',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Category background color', 'maa-extra' ),
			'param_name' => 'category_bg_color',
			'dependency' => array(
				'element' => 'category_outline',
				'value' => array(
					'0',
				)
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Category color', 'maa-extra' ),
			'param_name' => 'category_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'More color', 'maa-extra' ),
			'param_name' => 'more_color',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_1_hover_1',
					'grid_1_hover_2',
					'grid_1_hover_3',
					'grid_2_hover_2',
					'grid_4',
					'grid_5',
					'grid_7',
					'grid_8'
				)
			)
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_slider_title',
			'value' => __( 'Slider', 'maa-extra' ),
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_5',
					'grid_6',
					'grid_7',
					'grid_8'
				)
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Dots color', 'maa-extra' ),
			'param_name' => 'dots_color',
			'dependency' => array(
				'element' => 'pagination_show',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Nav button background color', 'maa-extra' ),
			'param_name' => 'nav_bg_color',
			'dependency' => array(
				'element' => 'navigation_buttons',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Nav button color', 'maa-extra' ),
			'param_name' => 'nav_color',
			'dependency' => array(
				'element' => 'navigation_buttons',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Scroll description color', 'maa-extra' ),
			'param_name' => 'scroll_desc_color',
			'dependency' => array(
				'element' => 'card_layout',
				'value' => array(
					'grid_4',
					'grid_5',
					'grid_7',
					'grid_8'
				)
			)
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_grid_title',
			'value' => __( 'Grid', 'maa-extra' ),
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Pagination color', 'maa-extra' ),
			'param_name' => 'pagination_color',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Pagination hover and active color', 'maa-extra' ),
			'param_name' => 'pagination_active_color',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_other_title',
			'value' => __( 'Other', 'maa-extra' ),
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );
