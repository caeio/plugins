<div class="maa-recent-projects-sc maa-splitscreen <?php echo $splitscreen_class . $bg_class . $css_class; ?>" 
	data-maa-splitscreen="<?php echo $recent_projects_uniqid; ?>" 
	data-options='<?php echo $multiscroll_json; ?>' 
	id="<?php echo esc_attr( $recent_projects_uniqid ); ?>"
	<?php if ( $appearance_effect != 'none' ) { echo ' data-aos="' . $appearance_effect . '"'; } ?> 
	<?php if ( $appearance_duration ) { echo ' data-aos-duration="' . intval( $appearance_duration ) . '"'; } ?>>
	
	<div class="ms-left">
		<?php foreach ( $projects_data as $project_index => $_project_object ) : ?>
		<?php
            $_project_object->image_size = $portfolio_images_size;
			$maa_project = NorExtraParser::project_object( $_project_object );
			$maa_project['in_popup'] = $open_in_popup;
			$maa_project['popup_navigation'] = $popup_show_nav_buttons;
			$maa_project['popup_mouse_scrolling'] = $popup_mouse_scrolling;
			$maa_project['popup_autoplay'] = $popup_autoplay;
			$maa_project['popup_autoplay_time'] = $popup_autoplay_time;
			$maa_project['hide_view_link_in_popup'] = $hide_view_link_in_popup; 
			MaaHelper::set_storage_item_data( $maa_project );
			echo '<div class="ms-section portfolio-item-wrap">';
			
			switch ( $card_layout ) {
				case 'grid_5':
					include( locate_template( 'parts/portfolio-cards/grid_5_left.php' ) );
					break;
			}

			echo '</div>';

            if ( $open_in_popup ) {
                ob_start();
                MaaHelper::set_storage_item_data( $maa_project );
                include( locate_template( 'parts/portfolio-cards/_popup.php' ) );
                MaaLayout::append_to_footer_buffer_content( ob_get_clean() );
            }
		?>
		<?php endforeach; ?>
	</div>
	<div class="ms-right">
		<?php foreach ( $projects_data as $project_index => $_project_object ) : ?>
		<?php
            $_project_object->image_size = $portfolio_images_size;
			$maa_project = NorExtraParser::project_object( $_project_object );
			$maa_project['in_popup'] = $open_in_popup;
			MaaHelper::set_storage_item_data( $maa_project );
			echo '<div class="ms-section portfolio-item-wrap">';
			
			switch ( $card_layout ) {
				case 'grid_5':
					include( locate_template( 'parts/portfolio-cards/grid_5_right.php' ) );
					break;
			}

			echo '</div>';

			if ( $open_in_popup ) {
				ob_start();
				MaaHelper::set_storage_item_data( $maa_project );
				include( locate_template( 'parts/portfolio-cards/_popup.php' ) );
				MaaLayout::append_to_footer_buffer_content( ob_get_clean() );
			}
		?>
		<?php endforeach; ?>
	</div>
	<div class="scroll<?php echo $scroll_desc_class; ?>">
		<?php esc_html_e( 'Scroll', 'maa-extra' ) ?>
	</div>
</div>