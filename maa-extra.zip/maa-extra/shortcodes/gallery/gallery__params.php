<?php

/**
* Visual Composer Maa Gallery shortcode params
*/



vc_map( array(
	'name' => __( 'Gallery', 'maa-extra' ),
	'description' => __( 'Simple lightbox gallery module', 'maa-extra' ),
	'base' => 'maa_gallery',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(
		// General
		array(
			'type' => 'attach_images',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Gallery images', 'maa-extra' ),
			'param_name' => 'content_images',
			'description' => __( 'First image will be main. Set title and caption in WordPress media.', 'maa-extra' ),
		),
		array(
		  'type' => 'dropdown',
		  'group' => __( 'General', 'maa-extra' ),
		  'heading' => __( 'Images size', 'maa-extra' ),
		  'param_name' => 'images_size',
		  'value' => array( 'Thumbnail', 'Medium', 'Large', 'Original' ),
		  "description" => __( "Choose gallery images size" )
	  	),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Hide overlay?', 'maa-extra' ),
			'param_name' => 'hide_overlay',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Show title on preview', 'maa-extra' ),
			'param_name' => 'show_title',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'dependency' => array(
				'element' => 'hide_overlay',
				'value' => array(
					'0'
				)
			)
		),

		// Grid
		array(
			'type' => 'maa_check',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Masonry grid', 'maa-extra' ),
			'param_name' => 'masonry_grid',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Metro style', 'maa-extra' ),
			'param_name' => 'metro_style',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Gap between images', 'maa-extra' ),
			'param_name' => 'gap',
			'std' => '15px',
			'description' => __( 'CSS value.', 'maa-extra' ),
		),
		array(
			'type' => 'maa_columns',
			'group' => __( 'Grid', 'maa-extra' ),
			'heading' => __( 'Columns', 'maa-extra' ),
			'param_name' => 'columns',
			'std' => '4-3-2-1'
		),

		// Pagination
		array(
			'type' => 'maa_check',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Use pagination', 'maa-extra' ),
			'param_name' => 'use_pagination',
			'description' => '',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Pagination type', 'maa-extra' ),
			'param_name' => 'pagination_type',
			'value' => array(
				__( 'Simple', 'maa-extra' ) => 'simple',
				__( 'Lazy load', 'maa-extra' ) => 'lazy_scroll',
				__( 'Load more button', 'maa-extra' ) => 'lazy_button',
			),
			'std' => 'simple',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => array(
					'1'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Pagination', 'maa-extra' ),
			'heading' => __( 'Number of items per page', 'maa-extra' ),
			'param_name' => 'pagination_items_per_page',
			'value' => '6',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => array(
					'1'
				)
			)
		),

		// Style
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_grid',
			'value' => __( 'Grid', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Overlay color', 'maa-extra' ),
			'param_name' => 'overlay_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Icon color', 'maa-extra' ),
			'param_name' => 'icon_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Pagination color', 'maa-extra' ),
			'param_name' => 'pagination_color',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Pagination hover and active color', 'maa-extra' ),
			'param_name' => 'pagination_active_color',
			'dependency' => array(
				'element' => 'use_pagination',
				'value' => '1',
			)
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_gallery',
			'value' => __( 'Gallery', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Background color', 'maa-extra' ),
			'param_name' => 'gallery_bg_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Image title color', 'maa-extra' ),
			'param_name' => 'gallery_title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Image subtitle color', 'maa-extra' ),
			'param_name' => 'gallery_subtitle_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Buttons color', 'maa-extra' ),
			'param_name' => 'gallery_buttons_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Slider navigation buttons background color', 'maa-extra' ),
			'param_name' => 'slider_nav_bg_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Slider navigation buttons color', 'maa-extra' ),
			'param_name' => 'slider_nav_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),

		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),


		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );
