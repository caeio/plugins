<?php 

/**
* Visual Composer Maa Split Box Column shortcode
*/

add_shortcode( 'maa_split_box_column', 'maa_split_box_column_func' );

function maa_split_box_column_func( $atts, $content = '' ) {
	// Assembling
	ob_start();
	include( plugin_dir_path( __FILE__ ) . 'split_box_column__view.php' );
	return ob_get_clean();
}