<?php


vc_map( array(
	'name' => __( 'Testimonials', 'maa-extra' ),
	'description' => __( 'Testimonial module', 'maa-extra' ),
	'base' => 'maa_testimonial',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'js_view' => 'VcMaaTestimonialView',
	'custom_markup' => '{{title}}<div class="vc_maa_testimonial-container">
			<div class="lines"><div class="line"></div><div class="line"></div><div class="line"></div></div>
			<div class="photo"></div>
			<div class="name">%%author%%</div>
			<div class="position"></div>
		</div>',
	'params' => array(
		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Testimonial layout', 'maa-extra' ),
			'param_name' => 'block_type_layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_071.svg',
					'key' => 'default',
					'title' => __( 'Default', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_065.svg',
					'key' => 'photo_top',
					'title' => __( 'Image Top', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_068.svg',
					'key' => 'photo_middle',
					'title' => __( 'Image Middle', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Content alignment', 'maa-extra' ),
			'param_name' => 'block_type_alignment_default',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_071.svg',
					'key' => 'center',
					'title' => __( 'Center', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_070.svg',
					'key' => 'left',
					'title' => __( 'Left', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_072.svg',
					'key' => 'right',
					'title' => __( 'Right', 'maa-extra' ),
				)
			),
			'dependency' => array(
				'element' => 'block_type_layout',
				'value' => array(
					'default'
				)
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Box alignment', 'maa-extra' ),
			'param_name' => 'block_type_alignment_top',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_065.svg',
					'key' => 'center',
					'title' => __( 'Center', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_064.svg',
					'key' => 'left',
					'title' => __( 'Left', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_066.svg',
					'key' => 'right',
					'title' => __( 'Right', 'maa-extra' ),
				)
			),
			'dependency' => array(
				'element' => 'block_type_layout',
				'value' => array(
					'photo_top'
				)
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Box alignment', 'maa-extra' ),
			'param_name' => 'block_type_alignment_middle',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_068.svg',
					'key' => 'center',
					'title' => __( 'Center', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_067.svg',
					'key' => 'left',
					'title' => __( 'Left', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_069.svg',
					'key' => 'right',
					'title' => __( 'Right', 'maa-extra' ),
				)
			),
			'dependency' => array(
				'element' => 'block_type_layout',
				'value' => array(
					'photo_middle'
				)
			)
		),
		array(
			'type' => 'textarea',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Testimonial text', 'maa-extra' ),
			'param_name' => 'quote'
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Image', 'maa-extra' ),
			'param_name' => 'photo',
			'description' => __( 'Choose author photo.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'block_type_layout',
				'value' => array(
					'photo_top',
					'photo_middle',
					'photo_and_mark'
				)
			)
		),
		array(
			'type' => 'textfield',
			'holder' => 'em',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Author', 'maa-extra' ),
			'param_name' => 'author',
			'description' => __( 'Testimonial author name.', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Position', 'maa-extra' ),
			'param_name' => 'position',
			'description' => __( 'For example, <strong>Product manager at caeio, LLC</strong>.', 'maa-extra' )
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_quote',
			'value' => __( 'Testimonial text', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'quote_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_author',
			'value' => __( 'Author', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'author_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_position',
			'value' => __( 'Position', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'position_typo',
		),

		// Style
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Image border color', 'maa-extra' ),
			'param_name' => 'image_border_color',
			'dependency' => array(
				'element' => 'block_type_layout',
				'value' => array(
					'photo_top',
					'photo_middle',
				)
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Testimonial color', 'maa-extra' ),
			'param_name' => 'quote_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Author color', 'maa-extra' ),
			'param_name' => 'author_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Position color', 'maa-extra' ),
			'param_name' => 'position_color'
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );