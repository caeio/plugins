<?php

/**
* Visual Composer Maa Heading shortcode params
*/

vc_map( array(
	'name' => __( 'Heading', 'maa-extra' ),
	'description' => __( 'Headnig block', 'maa-extra' ),
	'base' => 'maa_heading',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(
		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Heading layout', 'maa-extra' ),
			'param_name' => 'subtitle_type_layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_035.svg',
					'key' => 'bottom_subtitle',
					'title' => __( 'Bottom subtitle', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_038.svg',
					'key' => 'top_subtitle',
					'title' => __( 'Top subtitle', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_039.svg',
					'key' => 'without_subtitle',
					'title' => __( 'Without subtitle', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Content alignment', 'maa-extra' ),
			'param_name' => 'module_type_layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_035.svg',
					'key' => 'on_middle',
					'title' => __( 'Centred', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_036.svg',
					'key' => 'on_left',
					'title' => __( 'Left', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_037.svg',
					'key' => 'on_right',
					'title' => __( 'Right', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'textarea_raw_html',
			'holder' => 'div class="maa_heading_VC_gap"',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Title', 'maa-extra' ),
			'param_name' => 'title',
			'description' => __( 'Enter block title (HTML allowed).', 'maa-extra' ),
		),
		array(
			'type' => 'textarea_raw_html',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle', 'maa-extra' ),
			'param_name' => 'subtitle',
			'description' => __( 'Enter block subtitle (HTML allowed).', 'maa-extra' ),
			'dependency' => array(
				'element' => 'subtitle_type_layout',
				'value' => array(
					'bottom_subtitle',
					'top_subtitle'
				)
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle offset', 'maa-extra' ),
			'param_name' => 'subtitle_offset',
			'description' => __( 'CSS value.', 'maa-extra' ),
			'std' => '12px',
			'dependency' => array(
				'element' => 'subtitle_type_layout',
				'value' => array(
					'bottom_subtitle',
					'top_subtitle'
				)
			),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Heading tag', 'maa-extra' ),
			'param_name' => 'heading_type',
			'description' => __( 'Select the tag in which the title will be displayed.', 'maa-extra' ),
			'value' => array(
				__( '<h1>', 'maa-extra' ) => 'h1',
				__( '<h2>', 'maa-extra' ) => 'h2',
				__( '<h3>', 'maa-extra' ) => 'h3',
				__( '<h4>', 'maa-extra' ) => 'h4',
				__( '<h5>', 'maa-extra' ) => 'h5'
			),
			'std' => 'h3',
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Show divider?', 'maa-extra' ),
			'description' => __( 'If checked then divider will be hidden.', 'maa-extra' ),
			'param_name' => 'divider_visible',
			'value' => array(
				'Yes' => '0'
			),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Divider position', 'maa-extra' ),
			'param_name' => 'divider_alignment',
			'value' => array(
				__( 'Before title', 'maa-extra' ) => 'before_title',
				__( 'After title', 'maa-extra' ) => 'after_title'
			),
			'std' => 'before_title',
			'dependency' => array(
				'element' => 'divider_visible',
				'value' => array(
					'1'
				)
			),
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title typography', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_mobile_title',
			'value' => __( 'Title typography (Mobile)', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'mobile_title_typo'
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_subtitle',
			'value' => __( 'Subtitle typography', 'maa-extra' ),
			'dependency' => array(
				'element' => 'subtitle_type_layout',
				'value' => array(
					'bottom_subtitle',
					'top_subtitle'
				)
			),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'subtitle_typo',
			'dependency' => array(
				'element' => 'subtitle_type_layout',
				'value' => array(
					'bottom_subtitle',
					'top_subtitle'
				)
			),
		),

		// Style
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Subtitle color', 'maa-extra' ),
			'param_name' => 'subtitle_color',
			'dependency' => array(
				'element' => 'subtitle_type_layout',
				'value' => array(
					'bottom_subtitle',
					'top_subtitle'
				)
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Divider color', 'maa-extra' ),
			'param_name' => 'divider_color',
			'dependency' => array(
				'element' => 'divider_visible',
				'value' => '1',
			),
		),
		 
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	),
));