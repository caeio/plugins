<?php

/**
* Visual Composer Maa Message module shortcode params
*/

vc_map( array(
	'name' => __( 'Message Module', 'maa-extra' ),
	'description' => __( 'Messages and notifications module', 'maa-extra' ),
	'base' => 'maa_message_module',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Box type', 'maa-extra' ),
			'param_name' => 'layout',
			'value' => array(
				__( 'Default', 'maa-extra' ) => 'default',
				__( 'Warning', 'maa-extra' ) => 'warning',
				__( 'Primary', 'maa-extra' ) => 'primary',
				__( 'Success', 'maa-extra' ) => 'success',
				__( 'Danger', 'maa-extra' ) => 'danger'
			),
			'description' => __( 'Choose message module appearance type.', 'maa-extra' ),
		),
		array(
			'type' => 'textarea_raw_html',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Text', 'maa-extra' ),
			'param_name' => 'text',
			'description' => __( 'Enter message text (HTML allowed).', 'maa-extra' ),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Full width', 'maa-extra' ),
			'param_name' => 'full_width',
			'description' => __( 'If checked message box will be 100% width.', 'maa-extra' ),
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
			'std' => '1'
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Hide close button?', 'maa-extra' ),
			'param_name' => 'without_close_button',
			'description' => __( 'If checked close button will be hidden.', 'maa-extra' ),
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Use block as link?', 'maa-extra' ),
			'description' => __( 'If checked wrap message box in link tag.', 'maa-extra' ),
			'param_name' => 'use_link',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'vc_link',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Link', 'maa-extra' ),
			'param_name' => 'link',
			'dependency' => array(
				'element' => 'use_link',
				'value' => '1'
			)
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_text',
			'value' => __( 'Text typography', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'text_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_link',
			'value' => __( 'Link', 'maa-extra' ),
			'dependency' => array(
				'element' => 'use_link',
				'value' => '1'
			)
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'link_typo',
			'dependency' => array(
				'element' => 'use_link',
				'value' => '1'
			)
		),

		// Style
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Background color', 'maa-extra' ),
			'param_name' => 'bg_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Text color', 'maa-extra' ),
			'param_name' => 'text_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Link color', 'maa-extra' ),
			'param_name' => 'link_color',
			'dependency' => array(
				'element' => 'use_link',
				'value' => '1'
			)
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );