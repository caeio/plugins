<?php

/**
* Visual Composer Maa Video shortcode params
*/

vc_map( array(
	'name' => __( 'Video', 'maa-extra' ),
	'description' => __( 'Popup video module', 'maa-extra' ),
	'base' => 'maa_video',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Block layout', 'maa-extra' ),
			'param_name' => 'layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_076.svg',
					'key' => 'boxed_shape',
					'title' => __( 'Boxed', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_077.svg',
					'key' => 'outline',
					'title' => __( 'Outline', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_075.svg',
					'key' => 'with_preview',
					'title' => __( 'With preview', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Button layout', 'maa-extra' ),
			'param_name' => 'button_layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_073.svg',
					'key' => 'filled',
					'title' => __( 'Filled', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_074.svg',
					'key' => 'outline',
					'title' => __( 'Outline', 'maa-extra' ),
				),
			),
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Preview image', 'maa-extra' ),
			'param_name' => 'preview_image',
			'dependency' => array(
				'element' => 'layout',
				'value' => array(
					'with_preview'
				)
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Alignment', 'maa-extra' ),
			'param_name' => 'alignment',
			'value' => array(
				__( 'Left', 'maa-extra' ) => 'left',
				__( 'Center', 'maa-extra' ) => 'center',
				__( 'Right', 'maa-extra' ) => 'right'
			),
			'std' => 'center',
			'dependency' => array(
				'element' => 'layout',
				'value' => array(
					'boxed_shape',
					'outline'
				)
			),
		),
		array(
			'type' => 'textarea_raw_html',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Video title', 'maa-extra' ),
			'param_name' => 'title',
			'value' => '',
			'description' => __( 'HTML allowed.', 'maa-extra' )
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Video URL', 'maa-extra' ),
			'param_name' => 'link',
			'value' => '',
			'description' => 'For example, https://www.youtube.com/watch?v=dQw4w9WgXcQ'
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Start video from ... second', 'maa-extra' ),
			'param_name' => 'start_time',
			'value' => '',
			'description' => 'Supported by youtube player only'
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
			'dependency' => array(
				'element' => 'layout',
				'value' => array(
					'boxed_shape',
					'outline'
				)
			)
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
			'dependency' => array(
				'element' => 'layout',
				'value' => array(
					'boxed_shape',
					'outline'
				)
			)
		),

		// Style
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_button',
			'value' => __( 'Button', 'maa-extra' )
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Add shadow?', 'maa-extra' ),
			'param_name' => 'button_shadow',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Use "Call to action" animation?', 'maa-extra' ),
			'param_name' => 'button_anim',
			'value' => array(
				__( 'Yes', 'maa-extra' ) => '0'
			),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Button color', 'maa-extra' ),
			'param_name' => 'button_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Button color on hover', 'maa-extra' ),
			'param_name' => 'button_hover_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Icon color', 'maa-extra' ),
			'param_name' => 'icon_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Icon color on hover', 'maa-extra' ),
			'param_name' => 'icon_hover_color'
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_typo',
			'value' => __( 'Typography', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' )
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Background color', 'maa-extra' ),
			'param_name' => 'background_color',
			'dependency' => array(
				'element' => 'layout',
				'value' => array(
					'boxed_shape'
				)
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Border color', 'maa-extra' ),
			'param_name' => 'border_color',
			'dependency' => array(
				'element' => 'layout',
				'value' => array(
					'outline'
				)
			)
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );
