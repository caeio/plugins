<?php

/**
* Visual Composer Maa Video shortcode params
*/

vc_map( array(
	'name' => __( 'WooCommerce Categories', 'maa-extra' ),
	'description' => __( 'Styled WC categories block', 'maa-extra' ),
	'base' => 'maa_woo_categories',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(
		array(
			'type' => 'maa_woo_categories_types',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Categories', 'maa-extra' ),
			'param_name' => 'woo_categories',
			'description' => 'Leave empty if you want use all categories'
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Block layout', 'maa-extra' ),
			'param_name' => 'layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_078.svg',
					'key' => 'default',
					'title' => __( 'Default', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_081.svg',
					'key' => 'boxed',
					'title' => __( 'Boxed', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Block alignment', 'maa-extra' ),
			'param_name' => 'alignment',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_078.svg',
					'key' => 'left',
					'title' => __( 'Left', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_079.svg',
					'key' => 'center',
					'title' => __( 'Center', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_080.svg',
					'key' => 'right',
					'title' => __( 'Right', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Description position', 'maa-extra' ),
			'param_name' => 'subtitle_position',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_082.svg',
					'key' => 'top',
					'title' => __( 'Top', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_078.svg',
					'key' => 'bottom',
					'title' => __( 'Bottom', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Grid columns number', 'maa-extra' ),
			'param_name' => 'layout_columns',
			'value' => array(
				__( '1 column', 'maa-extra' ) => '1',
				__( '2 columns', 'maa-extra' ) => '2',
				__( '3 columns', 'maa-extra' ) => '3',
				__( '4 columns', 'maa-extra' ) => '4'
			),
			'description' => __( 'Choose grid columns number.', 'maa-extra' ),
		),
		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' )
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo'
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_description',
			'value' => __( 'Description', 'maa-extra' )
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'description_typo'
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_description',
			'value' => __( 'Button', 'maa-extra' )
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'button_typo'
		),

		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_colors',
			'value' => __( 'Colors', 'maa-extra' )
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Description color', 'maa-extra' ),
			'param_name' => 'description_color'
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Overlay color', 'maa-extra' ),
			'param_name' => 'overlay_color'
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_button',
			'value' => __( 'Button', 'maa-extra' )
		),
		array(
			'type' => 'maa_button',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => '',
			'param_name' => 'button'
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' )
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );