<?php

/**
* Visual Composer Maa Dynamic Text shortcode params
*/

vc_map( array(
	'name' => __( 'Dynamic Text', 'maa-extra' ),
	'description' => __( 'Effective dynamic text block', 'maa-extra' ),
	'base' => 'maa_dynamic_text',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'params' => array(

		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Alignment', 'maa-extra' ),
			'param_name' => 'alignment',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_035.svg',
					'key' => 'left',
					'title' => __( 'Left', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_036.svg',
					'key' => 'center',
					'title' => __( 'Center', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_037.svg',
					'key' => 'right',
					'title' => __( 'Right', 'maa-extra' ),
				)
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Static text before', 'maa-extra' ),
			'param_name' => 'pre_title',
			'description' => '',
		),
		array(
			'type' => 'param_group',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Dynamic text', 'maa-extra' ),
			'param_name' => 'dynamic_title',
			'description' => '',
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => __( 'Variant string', 'maa-extra' ),
					'param_name' => 'dynamic_part',
				),
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Static text after', 'maa-extra' ),
			'param_name' => 'post_title',
			'description' => '',
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Type speed', 'maa-extra' ),
			'param_name' => 'type_speed',
			'value' => array(
				__( 'Slow', 'maa-extra' ) => 'slow',
				__( 'Normal', 'maa-extra' ) => 'normal',
				__( 'Fast', 'maa-extra' ) => 'fast',
				__( 'Very fast', 'maa-extra' ) => 'very_fast',
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Loop', 'maa-extra' ),
			'param_name' => 'loop',
			'value' => array(
				'Yes' => '1'
			),
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_static',
			'value' => __( 'Static text', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'static_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_dynamic',
			'value' => __( 'Dynamic text', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'dynamic_typo',
		),
		
		// Style and colors
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'argenta_extra' ),
			'heading' => __( 'Static text color', 'argenta_extra' ),
			'param_name' => 'static_color',
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles and Colors', 'argenta_extra' ),
			'heading' => __( 'Dynamic text color', 'argenta_extra' ),
			'param_name' => 'dynamic_color',
		),

		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),


		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );