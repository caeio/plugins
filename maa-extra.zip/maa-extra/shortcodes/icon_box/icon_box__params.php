<?php

/**
* Visual Composer Maa Icon Box shortcode params
*/

vc_map( array(
	'name' => __( 'Icon Box', 'maa-extra' ),
	'description' => __( 'Maa eye catching icons', 'maa-extra' ),
	'base' => 'maa_icon_box',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'js_view' => 'VcMaaIconBoxView',
	'custom_markup' => '{{title}}<div class="vc_maa_icon_box-container">
			<div class="icon">%%icon%%</div>
			<div class="title">%%title%%</div>
			<div class="subtitle"></div>
			<div class="divider"></div>
			<div class="lines"><div class="line"></div><div class="line"></div><div class="line"></div></div>
			<div class="read_more"></div>
		</div>',
	'params' => array(
		// General
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Icon box layout', 'maa-extra' ),
			'param_name' => 'box_type_layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_012.svg',
					'key' => 'top_icon',
					'title' => __( 'Top icon', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_015.svg',
					'key' => 'left_icon',
					'title' => __( 'Side icon', 'maa-extra' ),
				),
				/*array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/param_box_layout_right_icon.png',
					'key' => 'right_icon',
					'title' => __( 'Right Icon', 'maa-extra' ),
				)*/
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Content alignment', 'maa-extra' ),
			'param_name' => 'box_alignment',
			'dependency' => array(
				'element' => 'box_type_layout',
				'value' => array(
					'top_icon'
				)
			),
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_012.svg',
					'key' => 'center',
					'title' => __( 'Center', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_013.svg',
					'key' => 'left',
					'title' => __( 'Left', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_014.svg',
					'key' => 'right',
					'title' => __( 'Right', 'maa-extra' ),
				)
			)
		),
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Box layout', 'maa-extra' ),
			'param_name' => 'content_full',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_015.svg',
					'key' => 'none',
					'title' => __( 'Float content', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_016.svg',
					'key' => 'full',
					'title' => __( 'Inline title', 'maa-extra' ),
				)
			),
			'dependency' => array(
				'element' => 'box_type_layout',
				'value' => array(
					'left_icon',
					'right_icon'
				)
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Title', 'maa-extra' ),
			'param_name' => 'title',
			'description' => __( 'Main title for block.', 'maa-extra' ),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Subtitle', 'maa-extra' ),
			'param_name' => 'subtitle',
			'description' => __( 'Subtitle.', 'maa-extra' ),
		),
		array(
			'type' => 'textarea',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Description', 'maa-extra' ),
			'param_name' => 'description',
			'description' => __( 'Description content.', 'maa-extra' ),
		),
		/*array(
			'type' => 'maa_check',
			'group' => __( 'General', 'maa-extra' ),
			'heading' => __( 'Full width content', 'maa-extra' ),
			'param_name' => 'content_full',
			'value' => array(
				'Yes' => '0'
			),
			'dependency' => array(
				'element' => 'box_type_layout',
				'value' => array(
					'left_icon',
					'right_icon'
				)
			),
		),*/

		// Icon
		array(
			'type' => 'maa_choose_box',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon layout', 'maa-extra' ),
			'param_name' => 'icon_type_layout',
			'value' => array(
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_017.svg',
					'key' => 'default',
					'title' => __( 'Default', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_018.svg',
					'key' => 'border',
					'title' => __( 'Border', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_019.svg',
					'key' => 'fill_and_border',
					'title' => __( 'Fill & border', 'maa-extra' ),
				),
				array(
					'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_020.svg',
					'key' => 'only_fill',
					'title' => __( 'Fill only', 'maa-extra' ),
				),
			)
		),
		array(
			'type' => 'maa_check',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Rounded icon shape', 'maa-extra' ),
			'param_name' => 'rounded_icon_shape',
			'value' => array(
				'Yes' => '0'
			),
			'dependency' => array(
				'element' => 'icon_type_layout',
				'value' => array(
					'border',
					'double',
					'fill_and_border',
					'only_fill'
				)
			),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon type', 'maa-extra' ),
			'param_name' => 'icon_type',
			'value' => array(
				__( 'Font icon', 'maa-extra' ) => 'font_icon',
				__( 'Custom image', 'maa-extra' ) => 'user_image'
			),
		),
		array(
			'type' => 'maa_icon_picker',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon', 'maa-extra' ),
			'param_name' => 'icon_as_icon',
			'description' => __( 'Choose icon.', 'maa-extra' ),
			'settings' => array(),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'font_icon'
				)
			)
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'Icon', 'maa-extra' ),
			'heading' => __( 'Icon image', 'maa-extra' ),
			'param_name' => 'icon_as_image',
			'description' => __( 'Choose icon image.', 'maa-extra' ),
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'user_image'
				)
			)
		),

		// Link
		array(
			'type' => 'maa_check',
			'group' => __( 'Link', 'maa-extra' ),
			'heading' => __( 'Use link?', 'maa-extra' ),
			'param_name' => 'use_link',
			'description' => __( 'Select if you want to block links to some page.', 'maa-extra' ),
			'value' => array(
				__( 'Yes, sure', 'maa-extra' ) => '0'
			)
		),
		array(
			'type' => 'vc_link',
			'group' => __( 'Link', 'maa-extra' ),
			'heading' => __( 'Link URL', 'maa-extra' ),
			'param_name' => 'link_url',
			'dependency' => array(
				'element' => 'use_link',
				'value' => array(
					'1'
				)
			),
			'description' => __( 'Fill title field to change the <strong>Read more</strong> label.', 'maa-extra' ),
		),

		// Typography
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_title',
			'value' => __( 'Title', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'title_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_subtitle',
			'value' => __( 'Subtitle', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'subtitle_typo',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'typo_tab_divider_description',
			'value' => __( 'Description', 'maa-extra' ),
		),
		array(
			'type' => 'maa_typography',
			'group' => __( 'Typography', 'maa-extra' ),
			'param_name' => 'description_typo',
		),

		// Style
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_content',
			'value' => __( 'Content', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Title color', 'maa-extra' ),
			'param_name' => 'title_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Subtitle color', 'maa-extra' ),
			'param_name' => 'subtitle_color',
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Description color', 'maa-extra' ),
			'param_name' => 'description_color',
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_icon',
			'value' => __( 'Icon', 'maa-extra' ),
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Fill color', 'maa-extra' ),
			'param_name' => 'fill_color',
			'dependency' => array(
				'element' => 'icon_type_layout',
				'value' => array(
					'fill_and_border',
					'only_fill'
				)
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Border color', 'maa-extra' ),
			'param_name' => 'border_color',
			'value' => 'brand',
			'dependency' => array(
				'element' => 'icon_type_layout',
				'value' => array(
					'fill_and_border',
					'border',
					'double'
				)
			)
		),
		array(
			'type' => 'maa_colorpicker',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Icon color', 'maa-extra' ),
			'param_name' => 'icon_color',
			'value' => 'brand',
			'dependency' => array(
				'element' => 'icon_type',
				'value' => array(
					'font_icon'
				)
			)
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_readmore',
			'value' => __( 'Readmore button', 'maa-extra' ),
			'dependency' => array(
				'element' => 'use_link',
				'value' => array(
					'1'
				)
			),
		),
		array(
			'type' => 'maa_button',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'readmore_button',
			'color_brand' => true,
			'dependency' => array(
				'element' => 'use_link',
				'value' => array(
					'1'
				)
			),
		),
		array(
			'type' => 'maa_divider',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),

		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),


		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );