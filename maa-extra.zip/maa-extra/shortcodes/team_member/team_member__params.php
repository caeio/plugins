<?php

/**
* Visual Composer Maa Team Member shortcode params
*/

vc_map( array(
		'name' => __( 'Team Member', 'maa-extra' ),
		'description' => __( 'Team member block', 'maa-extra' ),
		'base' => 'maa_team_member',
		'category' => __( 'Maa', 'maa-extra' ),
		'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
		'js_view' => 'VcMaaTeamMemberView',
		'custom_markup' => '{{title}}<div class="vc_maa_team_member-container">
				<div class="_contain">
					<div class="photo" style="background-image: url(\'' . plugin_dir_url( __FILE__ ) . 'images/sc_gap_user.svg\');"></div>
					<div class="name">%%name%%</div>
					<div class="position"></div>
				</div>
				<div class="lines"><div class="line"></div><div class="line"></div></div>
			</div>',
		'params' => array(
			// General
			array(
				'type' => 'maa_choose_box',
				'group' => __( 'General', 'maa-extra' ),
				'heading' => __( 'Team member layout', 'maa-extra' ),
				'param_name' => 'block_type_layout',
				'value' => array(
					array(
						'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_062.svg',
						'key' => 'full',
						'title' => __( 'Card details', 'maa-extra' ),
					),
					array(
						'icon' => plugin_dir_url( __FILE__ ) . 'images/wpb_params_063.svg',
						'key' => 'inner',
						'title' => __( 'Inner details', 'maa-extra' ),
					)
				)
			),
			array(
				'type' => 'attach_image',
				'group' => __( 'General', 'maa-extra' ),
				'heading' => __( 'Team member photo', 'maa-extra' ),
				'param_name' => 'photo',
				'description' => __( 'Choose member photo.', 'maa-extra' ),
			),
			array(
				'type' => 'textfield',
				'holder' => 'em',
				'group' => __( 'General', 'maa-extra' ),
				'heading' => __( 'Team member name', 'maa-extra' ),
				'param_name' => 'name',
				'description' => __( 'Team member name.', 'maa-extra' ),
			),
			array(
				'type' => 'textfield',
				'group' => __( 'General', 'maa-extra' ),
				'heading' => __( 'Team member position', 'maa-extra' ),
				'param_name' => 'position',
				'description' => __( 'For example, <em>Product manager at caeio, LLC</em>.', 'maa-extra' ),
			),
			array(
				'type' => 'textarea',
				'group' => __( 'General', 'maa-extra' ),
				'heading' => __( 'About team member', 'maa-extra' ),
				'param_name' => 'description',
				'description' => __( 'Tell what this remarkable team member in your team.', 'maa-extra' ),
			),
			array(
				'type' => 'textfield',
				'group' => __( 'General', 'maa-extra' ),
				'heading' => __( 'Custom link', 'maa-extra' ),
				'param_name' => 'member_link',
				'description' => __( 'Enter link to team member profile', 'maa-extra' ),
			),

			// Social links

			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-behance"></i> ' . __( 'Behance', 'maa-extra' ),
				'param_name' => 'behance_link'
			),
            array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-digg"></i> ' . __( 'Digg', 'maa-extra' ),
				'param_name' => 'digg_link'
			),
            array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-discord"></i> ' . __( 'Discord', 'maa-extra' ),
				'param_name' => 'discord_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-dribbble"></i> ' . __( 'Dribbble', 'maa-extra' ),
				'param_name' => 'dribbble_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-facebook-f"></i> ' . __( 'Facebook', 'maa-extra' ),
				'param_name' => 'facebook_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-flickr"></i> ' . __( 'Flickr', 'maa-extra' ),
				'param_name' => 'flickr_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-github"></i> ' . __( 'GitHub', 'maa-extra' ),
				'param_name' => 'github_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-instagram"></i> ' . __( 'Instagram', 'maa-extra' ),
				'param_name' => 'instagram_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-kaggle"></i> ' . __( 'Kaggle', 'maa-extra' ),
				'param_name' => 'kaggle_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-linkedin"></i> ' . __( 'LinkedIn', 'maa-extra' ),
				'param_name' => 'linkedin_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-medium-m"></i> ' . __( 'Medium', 'maa-extra' ),
				'param_name' => 'medium_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-mixer"></i> ' . __( 'Mixer', 'maa-extra' ),
				'param_name' => 'mixer_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-pinterest"></i> ' . __( 'Pinterest', 'maa-extra' ),
				'param_name' => 'pinterest_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-quora"></i> ' . __( 'Quora', 'maa-extra' ),
				'param_name' => 'quora_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-reddit"></i> ' . __( 'Reddit', 'maa-extra' ),
				'param_name' => 'reddit_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-snapchat"></i> ' . __( 'Snapchat', 'maa-extra' ),
				'param_name' => 'snapchat_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-soundcloud"></i> ' . __( 'SoundCloud', 'maa-extra' ),
				'param_name' => 'soundcloud_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-spotify"></i> ' . __( 'Spotify', 'maa-extra' ),
				'param_name' => 'spotify_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-teamspeak"></i> ' . __( 'TeamSpeak', 'maa-extra' ),
				'param_name' => 'teamspeak_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-telegram-plane"></i> ' . __( 'Telegram', 'maa-extra' ),
				'param_name' => 'telegram_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-tiktok"></i> ' . __( 'TikTok', 'maa-extra' ),
				'param_name' => 'tiktok_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-tumblr"></i> ' . __( 'Tumblr', 'maa-extra' ),
				'param_name' => 'tumblr_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-twitch"></i> ' . __( 'Twitch', 'maa-extra' ),
				'param_name' => 'twitch_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-twitter"></i> ' . __( 'Twitter', 'maa-extra' ),
				'param_name' => 'twitter_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-vimeo"></i> ' . __( 'Vimeo', 'maa-extra' ),
				'param_name' => 'vimeo_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-vine"></i> ' . __( 'Vine', 'maa-extra' ),
				'param_name' => 'vine_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-vk"></i> ' . __( 'Vkontakte', 'maa-extra' ),
				'param_name' => 'vk_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-whatsapp"></i> ' . __( 'Whatsapp', 'maa-extra' ),
				'param_name' => 'whatsapp_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-xing"></i> ' . __( 'Xing', 'maa-extra' ),
				'param_name' => 'xing_link'
			),
			array(
				'type' => 'textfield',
				'group' => __( 'Social Links', 'maa-extra' ),
				'heading' => '<i class="fab fa-youtube"></i> ' . __( 'Youtube', 'maa-extra' ),
				'param_name' => 'youtube_link'
			),

			// Typography
			array(
				'type' => 'maa_divider',
				'group' => __( 'Typography', 'maa-extra' ),
				'param_name' => 'typo_tab_divider_name',
				'value' => __( 'Name', 'maa-extra' ),
			),
			array(
				'type' => 'maa_typography',
				'group' => __( 'Typography', 'maa-extra' ),
				'param_name' => 'name_typo',
			),
			array(
				'type' => 'maa_divider',
				'group' => __( 'Typography', 'maa-extra' ),
				'param_name' => 'typo_tab_divider_position',
				'value' => __( 'Position', 'maa-extra' ),
			),
			array(
				'type' => 'maa_typography',
				'group' => __( 'Typography', 'maa-extra' ),
				'param_name' => 'position_typo',
			),
			array(
				'type' => 'maa_divider',
				'group' => __( 'Typography', 'maa-extra' ),
				'param_name' => 'typo_tab_divider_description',
				'value' => __( 'Description', 'maa-extra' ),
			),
			array(
				'type' => 'maa_typography',
				'group' => __( 'Typography', 'maa-extra' ),
				'param_name' => 'desription_typo',
			),

			// Styles
			array(
				'type' => 'maa_divider',
				'group' => __( 'Styles and Colors', 'maa-extra' ),
				'param_name' => 'style_tab_divider_content',
				'value' => __( 'Content', 'maa-extra' ),
			),
			array(
				'type' => 'maa_colorpicker',
				'group' => __( 'Styles and Colors', 'maa-extra' ),
				'heading' => __( 'Overlay color', 'maa-extra' ),
				'param_name' => 'overlay_color',
			),
			array(
				'type' => 'maa_colorpicker',
				'group' => __( 'Styles and Colors', 'maa-extra' ),
				'heading' => __( 'Name color', 'maa-extra' ),
				'param_name' => 'name_color',
			),
			array(
				'type' => 'maa_colorpicker',
				'group' => __( 'Styles and Colors', 'maa-extra' ),
				'heading' => __( 'Position text color', 'maa-extra' ),
				'param_name' => 'position_color',
			),
			array(
				'type' => 'maa_colorpicker',
				'group' => __( 'Styles and Colors', 'maa-extra' ),
				'heading' => __( 'Description color', 'maa-extra' ),
				'param_name' => 'description_color',
			),
			array(
				'type' => 'maa_colorpicker',
				'group' => __( 'Styles and Colors', 'maa-extra' ),
				'heading' => __( 'Social buttons color', 'maa-extra' ),
				'param_name' => 'social_color',
			),
			array(
				'type' => 'maa_colorpicker',
				'group' => __( 'Styles and Colors', 'maa-extra' ),
				'heading' => __( 'Social buttons hover color', 'maa-extra' ),
				'param_name' => 'social_hover_color',
			),
			array(
				'type' => 'maa_divider',
				'group' => __( 'Styles and Colors', 'maa-extra' ),
			'param_name' => 'style_tab_divider_other',
			'value' => __( 'Other', 'maa-extra' ),
		),
		
		// Custom Class
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		// Appear Effect
		array(
			'type' => 'dropdown',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Appear effect', 'maa-extra' ),
			'param_name' => 'appearance_effect',
			'value' => array(
				__( 'None', 'maa-extra' ) => 'none',
				__( 'Fade up', 'maa-extra' ) => 'fade-up',
				__( 'Fade down', 'maa-extra' ) => 'fade-down',
				__( 'Fade right', 'maa-extra' ) => 'fade-right',
				__( 'Fade left', 'maa-extra' ) => 'fade-left',
				__( 'Flip up', 'maa-extra' ) => 'flip-up',
				__( 'Flip down', 'maa-extra' ) => 'flip-down',
				__( 'Zoom in', 'maa-extra' ) => 'zoom-in',
				__( 'Zoom out', 'maa-extra' ) => 'zoom-out'
			)
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Appear Effect', 'maa-extra' ),
			'heading' => __( 'Animation duration', 'maa-extra' ),
			'param_name' => 'appearance_duration',
			'description' => __( 'Duration accept values from 50 to 3000 (ms), with step 50.', 'maa-extra' ),
		),
	)
) );
