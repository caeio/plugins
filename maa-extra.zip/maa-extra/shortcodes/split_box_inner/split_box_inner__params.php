<?php

/**
* Visual Composer Maa Split Box shortcode params
*/

vc_map( array(
	'name' => __( 'Split Box', 'maa-extra' ),
	'description' => __( 'Split view box', 'maa-extra' ),
	'base' => 'maa_split_box_inner',
	'category' => __( 'Maa', 'maa-extra' ),
	'icon' => plugin_dir_url( __FILE__ ) . 'images/icon.svg',
	'js_view' => 'VcMaaSplitBoxColumnView',
	'show_settings_on_create' => false,
	'as_parent' => array( 
		'only' => 'maa_split_box_column_inner'
	),
	'as_child' => array( 
		'only' => 'maa_split_box_column'
	),
	'default_content' => '[maa_split_box_column_inner][/maa_split_box_column_inner][maa_split_box_column_inner][/maa_split_box_column_inner]',
	'params' => array(
		array(
			'type' => 'textfield',
			'group' => __( 'Styles and Colors', 'maa-extra' ),
			'heading' => __( 'Custom CSS class', 'maa-extra' ),
			'param_name' => 'css_class',
			'description' => __( 'If you want to add styles to a specific unit, use this field to add CSS class.', 'maa-extra' ),
		),

		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles for Left Block', 'maa-extra' ),
			'heading' => __( 'Background color', 'maa-extra' ),
			'param_name' => 'bg_first_color',
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'Styles for Left Block', 'maa-extra' ),
			'heading' => __( 'Background image', 'maa-extra' ),
			'param_name' => 'bg_first_image',
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles for Left Block', 'maa-extra' ),
			'heading' => __( 'Overlay color', 'maa-extra' ),
			'param_name' => 'bg_first_overlay_color',
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles for Left Block', 'maa-extra' ),
			'heading' => __( 'Background size', 'maa-extra' ),
			'param_name' => 'bg_first_size',
			'value' => array(
				__( 'Auto', 'maa-extra' ) => '',
				__( 'Contain', 'maa-extra' ) => 'contain',
				__( 'Cover', 'maa-extra' )   => 'cover',
				__( 'auto 100%', 'maa-extra' )  => 'auto 100%',
				__( '100% auto', 'maa-extra' )  => '100% auto',
				__( '100% 100%', 'maa-extra' )  => '100% 100%',
			),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles for Left Block', 'maa-extra' ),
			'heading' => __( 'Background parallax type', 'maa-extra' ),
			'param_name' => 'bg_first_parallax',
			'value' => array(
				__( 'None', 'maa-extra' ) => '',
				__( 'Vertical', 'maa-extra' ) => 'vertical',
				__( 'Horizontal', 'maa-extra' ) => 'horizontal'
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Styles for Left Block', 'maa-extra' ),
			'heading' => __( 'Parallax speed', 'maa-extra' ),
			'param_name' => 'bg_first_parallax_speed',
			'description' => __( 'Parallax speed (default 1.0).', 'maa-extra' ),
			'dependency' => array(
				'element' => 'bg_first_parallax',
				'value' => array(
					'vertical',
					'horizontal'
				)
			),
		),

		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles for Right Block', 'maa-extra' ),
			'heading' => __( 'Background color', 'maa-extra' ),
			'param_name' => 'bg_second_color',
		),
		array(
			'type' => 'attach_image',
			'group' => __( 'Styles for Right Block', 'maa-extra' ),
			'heading' => __( 'Background image', 'maa-extra' ),
			'param_name' => 'bg_second_image',
		),
		array(
			'type' => 'colorpicker',
			'group' => __( 'Styles for Right Block', 'maa-extra' ),
			'heading' => __( 'Overlay color', 'maa-extra' ),
			'param_name' => 'bg_second_overlay_color',
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles for Right Block', 'maa-extra' ),
			'heading' => __( 'Background size', 'maa-extra' ),
			'param_name' => 'bg_second_size',
			'value' => array(
				__( 'Auto', 'maa-extra' ) => '',
				__( 'Contain', 'maa-extra' ) => 'contain',
				__( 'Cover', 'maa-extra' )   => 'cover',
				__( 'auto 100%', 'maa-extra' )  => 'auto 100%',
				__( '100% auto', 'maa-extra' )  => '100% auto',
				__( '100% 100%', 'maa-extra' )  => '100% 100%',
			),
		),
		array(
			'type' => 'dropdown',
			'group' => __( 'Styles for Right Block', 'maa-extra' ),
			'heading' => __( 'Background parallax type', 'maa-extra' ),
			'param_name' => 'bg_second_parallax',
			'value' => array(
				__( 'None', 'maa-extra' ) => '',
				__( 'Vertical', 'maa-extra' ) => 'vertical',
				__( 'Horizontal', 'maa-extra' )   => 'horizontal'
			),
		),
		array(
			'type' => 'textfield',
			'group' => __( 'Styles for Right Block', 'maa-extra' ),
			'heading' => __( 'Parallax speed', 'maa-extra' ),
			'param_name' => 'bg_second_parallax_speed',
			'description' => __( 'Parallax speed (default 1.0).', 'maa-extra' ),
			'dependency' => array(
				'element' => 'bg_second_parallax',
				'value' => array(
					'vertical',
					'horizontal'
				)
			),
		),
	)
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Maa_Split_Box_Inner extends WPBakeryShortCodesContainer {
		
		public function getColumnControls( $controls = 'full', $extended_css = '' ) {
			$controls_start = '<div class="vc_controls vc_controls-visible controls_column' . ( ! empty( $extended_css ) ? " {$extended_css}" : '' ) . '">';
			$controls_end = '</div>';

			if ( 'bottom-controls' === $extended_css ) {
				$control_title = sprintf( __( 'Append to this %s', 'maa-extra' ), strtolower( $this->settings( 'name' ) ) );
			} else {
				$control_title = sprintf( __( 'Prepend to this %s', 'maa-extra' ), strtolower( $this->settings( 'name' ) ) );
			}

			$controls_move = '<a class="vc_control column_move" data-vc-control="move" href="#" title="' . sprintf( __( 'Move this %s', 'maa-extra' ), strtolower( $this->settings( 'name' ) ) ) . '"><span class="vc_icon"></span></a>';
			$controls_add = ''; //'<a class="vc_control column_add" data-vc-control="add" href="#" title="' . $control_title . '"><span class="vc_icon"></span></a>';
			$controls_edit = '<a class="vc_control column_edit" data-vc-control="edit" href="#" title="' . sprintf( __( 'Edit this %s', 'maa-extra' ), strtolower( $this->settings( 'name' ) ) ) . '"><span class="vc_icon"></span></a>';
			$controls_clone = '<a class="vc_control column_clone" data-vc-control="clone" href="#" title="' . sprintf( __( 'Clone this %s', 'maa-extra' ), strtolower( $this->settings( 'name' ) ) ) . '"><span class="vc_icon"></span></a>';
			$controls_delete = '<a class="vc_control column_delete" data-vc-control="delete" href="#" title="' . sprintf( __( 'Delete this %s', 'maa-extra' ), strtolower( $this->settings( 'name' ) ) ) . '"><span class="vc_icon"></span></a>';
			$controls_full = $controls_move . $controls_add . $controls_edit . $controls_clone . $controls_delete;

			$editAccess = vc_user_access_check_shortcode_edit( $this->shortcode );
			$allAccess = vc_user_access_check_shortcode_all( $this->shortcode );

			if ( ! empty( $controls ) ) {
				if ( is_string( $controls ) ) {
					$controls = array( $controls );
				}
				$controls_string = $controls_start;
				foreach ( $controls as $control ) {
					$control_var = 'controls_' . $control;
					if ( ( $editAccess && 'edit' == $control ) || $allAccess ) {
						if ( isset( ${$control_var} ) ) {
							$controls_string .= ${$control_var};
						}
					}
				}

				return $controls_string . $controls_end;
			}

			if ( $allAccess ) {
				return $controls_start . $controls_full . $controls_end;
			} elseif ( $editAccess ) {
				return $controls_start . $controls_edit . $controls_end;
			}

			return $controls_start . $controls_end;
		}


	}
}